;;; ==================================================================
;;;  FiberQ CAD -- fq-jezik.lsp
;;;  Jezik interfejsa.  Copyright (c) 2026.  MIT licenca, vidi LICENSE.
;;; ==================================================================
;;;
;;;  OVAJ FAJL SE UCITAVA PRVI, pre fq-kucista.lsp i fq-sema.lsp.
;;;
;;;  Redosled nije stvar ukusa nego uslov: ~500 poziva fq:t stoji unutar
;;;  defun tela, ali BANER na dnu svakog fajla se izvrsava na nivou
;;;  fajla, u trenutku ucitavanja.  Da fq:t tada ne postoji, ucitavanje
;;;  bi stalo TIHO i nijedan defun ispod te linije vise ne bi postojao.
;;;
;;;  Redosled je obezbedjen na tri mesta, jer postoje tri puta ucitavanja:
;;;
;;;    1. Paket (PackageContents.xml).  IZMERENO 21.08.2026, iz dva
;;;       odvojena restarta: AutoCAD ucitava ComponentEntry OBRNUTO od
;;;       redosleda u XML-u.  install.ps1 upisuje sema -> kucista ->
;;;       ribbon, a baner ispisuje ribbon -> kucista -> sema.  Nije
;;;       abecedno; to bi dalo kucista -> ribbon -> sema.
;;;       Zato fq-jezik.lsp u XML-u stoji POSLEDNJI -- da bi bio prvi.
;;;
;;;    2. fq:lib u fq-ribbon.lsp, koji biblioteku ucitava na zahtev.
;;;       Tamo fq-jezik.lsp ide ispred svih.
;;;
;;;    3. Rucni APPLOAD.  Abecedno je fq-jezik prvi (j < k < r < s), pa
;;;       ovaj put ne trazi nista.
;;;
;;;  I pored sva tri, baner NE SME da racuna na ovaj fajl.  Ako ga neko
;;;  obrise iz podrske, ostala tri moraju da se ucitaju i rade na
;;;  engleskom.  Zato je baner u sva tri fajla pod strazom
;;;  (atoms-family 1 '("FQ:T")) -- isti obrazac kojim fq-sema.lsp vec
;;;  proverava postoji li fq:porram iz fq-kucista.lsp.
;;;
;;;  Sve ostalo (poruke komandi, DCL, paleta, tekst u crtezu) je unutar
;;;  defun tela i ne treba mu straza: dok komanda moze da se pozove,
;;;  biblioteka je vec cela ucitana.
;;; ------------------------------------------------------------------

;;;  CIST ASCII.  princ i DCL ne smeju dijakritiku, pa srpske niske ovde
;;;  idu bez nje -- c, s, z umesto c-kvacica, s-kvacica, z-kvacica.
;;;  Isto pravilo koje vec vazi za ostatak projekta.

;; Isto kao na vrhu ostala tri fajla.  Ne oslanja se na to da ga je neko
;; drugi vec pozvao: fq:tf koristi vl-string-subst, a ovaj fajl se
;; ucitava PRVI -- dakle pre svakog drugog (vl-load-com) u projektu.
(vl-load-com)

;; Postavlja se BEZUSLOVNO, isto kao u ostala tri fajla.  U sesiji ostaje
;; verzija poslednje ucitanog -- namerno: kod mesanog para fajlova bas to
;; je podatak koji hoces da vidis.  test-lisp.ps1 proverava da su sve iste.
(setq *FQ-VERZIJA* "1.0.0")

;;; ------------------------------------------------------------------
;;;  1. TEKUCI JEZIK
;;;
;;;  "EN" ili "SR".  Engleski je podrazumevan -- to je i ono sto
;;;  recenzija App Store-a ocekuje, jer srpskog nema na listi jezika
;;;  prodavnice i recenzent ne moze da testira ono sto ne razume.
;;;
;;;  BEZ CITANJA (getvar "LOCALE").  Razlog je cinjenican, ne stvar
;;;  ukusa: AutoCAD nema srpsku verziju, pa LOCALE ne moze vratiti kod
;;;  za srpski ni na jednoj masini.  Automatika bi svakom korisniku uvek
;;;  dala engleski -- dakle nista, uz granu koja se ne moze isprobati.
;;; ------------------------------------------------------------------

(setq *FQ-JEZICI* '("EN" "SR"))

;; Kljuc u AutoCAD profilu.  Provereno 21.08.2026: setenv prezivi i
;; restart i ponovnu instalaciju paketa, pa jezik ne treba svoj .dat
;; fajl -- za razliku od boja i kataloga, koji nose sadrzaj, a ne jedan
;; podatak od dva slova.
(setq *FQ-JEZ-KLJUC* "FQ-JEZIK")

;; Vraca "EN" ili "SR", nikad nista trece i nikad nil.  Nepoznata
;; vrednost u profilu (rucno menjana, ili iz neke buduce verzije) svodi
;; se na engleski umesto da obori prvi strcat na koji naidje.
(defun fq:jezok (s)
  (if (and s (member (strcase s) *FQ-JEZICI*)) (strcase s) "EN"))

(setq *fq-jezik* (fq:jezok (getenv *FQ-JEZ-KLJUC*)))

;;; ------------------------------------------------------------------
;;;  2. TABELE NISKI
;;;
;;;  KLJUC JE NEUTRALAN SIMBOL, ne srpska recenica.  Recenica kao kljuc
;;;  znaci da svaka ispravka pravopisa lomi prevod, tiho -- ista zamka
;;;  zbog koje u xdata ide kod a ne rec.
;;;
;;;  Oblik kljuca je  oblast.pojam.detalj:
;;;
;;;    start.*   baner pri ucitavanju
;;;    jezik.*   komanda FQJEZIK
;;;
;;;  Oblasti koje dolaze u blokovima 3-8: kabl, kuc, nast, spl, bom,
;;;  budzet, opste.  Grupisanje nije ukras -- provera iz bloka 10 po
;;;  njemu javlja "oblast kabl nema prevod za X", sto ravan spisak od
;;;  petsto kljuceva ne moze.
;;;
;;;  ENGLESKA TABELA JE MERODAVNA.  fq:t trazi prvo u tekucem jeziku, pa
;;;  u engleskom, pa vraca sam kljuc.  Zato nepotpun srpski prevod daje
;;;  englesku recenicu, a ne golu sifru u komandnoj liniji.
;;;
;;;  %1 do %9 su umeci -- vidi fq:tf.  Broj, a ne redosled u strcat-u,
;;;  jer red reci nije isti u dva jezika.
;;; ------------------------------------------------------------------

(setq *FQ-STR-EN*
 '(
   ;; --- baner ---
   ("start.sema"          . " -- fq-sema.lsp loaded.  FIBERQ for the palette, FQHELP for the guide.")
   ("start.kucista"       . " -- fq-kucista.lsp loaded.")
   ("start.ribbon"        . " -- fq-ribbon.lsp loaded.  FQRIBBON / FQRIBBONOFF, palette is FIBERQ.")
   ("start.kuc.komande"   . "\n  FQKUC dialog,  FQZOK / FQPP / FQMDU,  -FQZOK for the command line.")
   ("start.cc.ucitano"    . "\n  Color code standards loaded: %1  from %2")
   ("start.cc.samo"       . "\n  Color code: built in only (%1).  Build your own with the Color code button.")
   ("start.cc.aktivan"    . "\n  Active color code: %1")
   ("start.kbl.ucitan"    . "\n  Cable catalogue loaded from %1")
   ("start.kbl.dopisano"  . "\n  Cable types added from the shipped catalogue: %1.  FQKABLSAVE stores them permanently.")
   ("start.kat.ucitan"    . "\n  Housing catalogue loaded from %1")
   ("start.kat.dopisano"  . "\n  Housing types added from the shipped catalogue: %1.  FQKATSAVE stores them permanently.")
   ("start.orijentacija"  . "\n  Orientation is set on the palette and in the cable dialog.\n")
   ;; --- FQJEZIK ---
   ;; Do bloka 7 traka ima samo jedan jezik.  Poruka to kaze umesto da
   ;; cuti -- inace izgleda kao da FQJEZIK ne radi.
   ;;  Recenica o traci je do bloka 7b glasila "the ribbon still follows
   ;;  the package language" -- tada je to bilo tacno, jer je paket bio
   ;;  jedan.  Od bloka 7b su paketa dva i fq:trakazam ih menja sam, pa
   ;;  je stara recenica postala netacna bas u trenutku kad se traka pred
   ;;  korisnikom zamenila.
   ;;
   ;;  Novo nacrtano, ne "sve": vec nacrtan TEXT je geometrija i ostaje
   ;;  na jeziku na kom je nastao.
   ("jezik.postavljen"    . "\nInterface language: %1.  Applies to what is drawn from now on.")
   ("jezik.isti"          . "\nInterface language is already %1.")
   ("jezik.naziv.EN"      . "English")
   ("jezik.naziv.SR"      . "Serbian")
   ;; --- promptovi trajnih nabrajanja (blok 3) ---
   ;;
   ;;  %1 je SPISAK TOKENA, %2 podrazumevana vrednost.  Nijedno od toga
   ;;  ne stoji ovde kao tekst, i to je uslov, ne stednja: tokene zna
   ;;  *FQ-KODOVI* (odnosno *FQ-STATUSI*), pa ih fq:tokpit gradi iz iste
   ;;  tabele iz koje ih gradi i initget.  Prepisan spisak u ovoj tabeli
   ;;  bio bi drugi izvor istine i razisao bi se tiho -- initget koji ne
   ;;  zna za token samo ga ne prihvati, a prompt koji ga navodi ostane
   ;;  da laze.
   ;;
   ;;  Uglaste zagrade su OVDE, ne u fq:tokpit: neka mesta iza njih nose
   ;;  jos i podrazumevanu vrednost, a neka ne.
   ("opste.pitaj.status"   . "\nStatus [%1] <%2>: ")
   ("vlakno.pitaj.vrsta"   . "\nFiber type [%1] <%2>: ")
   ("vlakno.pitaj.namena"  . "\nPurpose [%1] <%2>: ")
   ("kabl.pitaj.kategorija". "\nCable category [%1] <%2>: ")
   ("odo.pitaj.montaza"    . "\nMounting [%1] <%2>: ")
   ("nast.pitaj.tip"       . "\nType [%1] <%2>: ")
   ;; --- zajednicki recnik (blok 4.1) ---
   ;;
   ;;  Dvadeset poruka koje stoje na 87 mesta.  Nisu izdvojene zato sto
   ;;  se ponavljaju nego zato sto MORAJU biti iste: "\nOtkazano." je
   ;;  jedini odgovor na Esc u celom dodatku i korisnik ga prepoznaje kao
   ;;  jedan te isti dogadjaj.  Trideset tri zasebna prevoda iste reci
   ;;  pre ili kasnije daju trideset tri nijanse.
   ("opste.otkazano"           . "\nCancelled.")
   ("opste.nista"              . "\nNothing selected.")
   ("opste.bez.oznake"         . "(no label)")
   ("opste.pregled.ne"         . "\n  Preview not available, plain point entry.")
   ;;  Razlog se ISPISUJE, ne guta.  Pregled pada kroz
   ;;  vl-catch-all-apply, pa je poruka jedini trag koji ostaje;
   ;;  bez nje se prijava svodi na "nekad ne radi".
   ("opste.pregled.zasto"      . "\n  Reason: %1")
   ("opste.nije.vlakno"        . "\nThat is not a fiber.")
   ("opste.nije.element"       . "\nThat is not a FiberQ element.")
   ("opste.nema.elemenata"     . "\nThe drawing has no FIBERQ elements.")
   ("opste.dcl.ne"             . "\nCannot write the DCL file to the temp folder.")
   ("opste.ram.ugao"           . "\nCannot read the frame angle.")
   ("opste.ram.temena"         . "\nThat frame does not have four corners.")
   ("opste.poravnanje.potroseno" . "\nAlignment used up and cleared.")
   ("opste.poravnanje.ponisti" . "\nIf you do not want that, the Align with cable button clears it.")
   ;; Poslednje dve od ove cetiri idu USRED reda -- splajs ispisuje red
   ;; po vlaknu -- pa nemaju \n na pocetku.  Dva razmaka su uvlaka.
   ("spoj.presk.nijevlakno"    . "\n  skipped, not a fiber")
   ("spoj.presk.isto"          . "\n  skipped, the same fiber picked twice")
   ("spoj.red.nijevlakno"      . "  not a fiber")
   ("spoj.red.otkazano"        . "  cancelled")
   ("kuc.ram.fqdodaj"          . "\n  You can widen the frame with FQDODAJ.")
   ("kuc.ogledalo"             . "\n  Mirrored: the bundle arrives from the other side, so the body goes to the right of the connector column.")
   ("kuc.sirenje.otkazano"     . "\n  Widening cancelled.  FQDODAJ does it later.")
   ("kabl.deo.bezduz"          . "\n  That segment has no length.")
   ("kabl.nema.vlakana"        . "\nCannot find the fibers of that cable.")
   ("kabl.polozaj.ormar"       . "\nPosition taken from the cabinet, the cable starts there.")
   ;; --- traka (blok 4.1) ---
   ;;
   ;;  Ove idu kroz fq:rt, ne kroz fq:tf -- vidi strazu na vrhu
   ;;  fq-ribbon.lsp.  Dve poruke tog fajla NISU ovde i ne treba da budu:
   ;;  one prijavljuju da biblioteka fali, pa ne smeju da zavise od nje.
   ("opste.da"                 . "yes")
   ("opste.ne"                 . "no")
   ("opste.orijentacija.h"     . "horizontal")
   ("opste.orijentacija.v"     . "vertical")
   ("traka.greska"             . "\nFiberQ, error: %1")
   ("traka.stanje"             . "\nFiberQ  status: %1   orientation: %2   mouse preview: %3   cable widens housing: %4   snapping: %5   color code: %6")
   ("traka.vec.ucitana"        . "\nThe FiberQ ribbon is already loaded.")
   ("traka.nije.ucitana"       . "\nThe FiberQ ribbon is not loaded.")
   ("traka.nema.cuix"          . "\nCannot find FiberQ.cuix.")
   ("traka.nema.cuix.alert"    . "FiberQ\n\nCannot find FiberQ.cuix.\n\nAdd the folder holding FiberQ.cuix to\nOptions / Files / Support File Search Path,\nthen run FQRIBBON again.")
   ("traka.cuix.greska"        . "\nCannot load FiberQ.cuix: %1")
   ("traka.ucitana"            . "\nFiberQ ribbon loaded from %1")
   ("traka.uklanjanje.greska"  . "\nCannot unload the ribbon: %1")
   ("traka.uklonjena"          . "\nFiberQ ribbon unloaded.")
   ;; --- specifikacija, fq:tallytxt (blok 4.2) ---
   ;;
   ;;  Jedan kljuc po vrsti stavke.  Neobavezni delovi su UMECI koji sme
   ;;  da budu prazni (fq:bomd), pa recenica ostaje jedna i prevodilac
   ;;  sme da pomeri red reci -- ukljucujuci i to gde stoji montaza.
   ;;
   ;;  ODO je na engleskom FDH, ZOK je FAT.  Kljuc u xdata se ne menja.
   ("bom.vlakno"           . "Fibers, %1%2%3%4")
   ("bom.vlakno.prolazna"  . ", through")
   ("bom.vlakno.presecena" . ", cut")
   ("bom.varenje"          . "Splices")
   ("bom.varenje.u"        . "Splices in %1")
   ("bom.nastavak"         . "Closures %1%2")
   ("bom.spliter"          . "Splitters %1")
   ("bom.odf"              . "ODF%1, %2 of %3 used")
   ("bom.pp"               . "Patch panel%1, %2 of %3 used")
   ("bom.odo"              . "FDH %1%2, %3 used")
   ("bom.mdu"              . "MDU %1%2, %3 used")
   ("bom.zok"              . "FAT%1 %2x%3%4%5")
   ("bom.zok.spliter"      . "splitter %1")
   ("bom.olt"              . "OLT %1 PON")
   ("bom.ont"              . "ONT")
   ("bom.pon"              . "PON ports")
   ("bom.privod"           . "Drop cables")
   ("bom.rezerva"          . "Slack %1 m")
   ("bom.naslov"           . "\n--- BILL OF MATERIALS ---")
   ("bom.upisano"          . "\nRows written: %1")
   ;; --- FQPROVERA (blok 4.2) ---
   ;;
   ;;  Brojevi nalaza [1]..[6] su deo teksta, ne umetak: oni su REDNI
   ;;  BROJ provere, isti u oba jezika, i korisnik po njima pita.
   ("prov.naslov"          . "\n--- DRAWING CHECK ---")
   ("prov.zaglavlje"       . "\n  fibers %1, closures %2, splices %3")
   ("prov.stavka"          . "\n        %1")
   ("prov.jos"             . "\n        ... and %1 more")
   ("prov.1.ima"           . "\n  [1] duplicate fiber id: %1")
   ("prov.1.nema"          . "\n  [1] duplicate fiber id: none")
   ("prov.1.savet"         . "\n        someone probably copied a fiber, the data is copied with it")
   ("prov.2.ima"           . "\n  [2] cable %1, duplicate ordinals: ")
   ("prov.2.nema"          . "\n  [2] ordinals within cables: no duplicates")
   ("prov.2.kabl"          . "\n      cable %1: %2 fibers carry that label%3%4")
   ("prov.2.presecenih"    . ", %1 of them cut")
   ("prov.2.spojeno"       . ", %1 joined into other cables")
   ("prov.3.ima"           . "\n  [3] port taken more than once: %1")
   ("prov.3.nema"          . "\n  [3] ODF and FDH ports: none taken twice")
   ("prov.4.ima"           . "\n  [4] closure without a splice: %1")
   ("prov.4.nema"          . "\n  [4] closures: each has at least one splice")
   ("prov.4.savet"         . "\n        if fibers only pass through them, those are latent closures (NL)")
   ("prov.4.latentni"      . "\n      latent closures skipped: %1   (they are not meant to hold splices)")
   ("prov.5.ima"           . "\n  [5] splice without a fiber: %1 / %2%3")
   ("prov.5.mesto"         . "  in %1")
   ("prov.5.nema"          . "\n  [5] splices: all point to existing fibers")
   ("prov.6"               . "\n  [6] working fibers without a termination: %1%2")
   ("prov.6.napomena"      . "   (not an error while the route is still being built)")
   ("prov.ukupno"          . "\n  TOTAL findings: %1")
   ("prov.cist"            . "\n  The drawing is clean.")
   ("info.nema"            . "\nNo FIBERQ data on this entity.")

   ;;  Natpisi polja za c:FQINFO.  Kljuceve predaje *FQ-POLJA* iz
   ;;  fq-sema.lsp, dakle kao PROMENLJIVU -- zato ih ne cuva odeljak
   ;;  "kljuc mora biti doslovna niska" nego odeljak koji gleda samu
   ;;  tabelu.  Svaki nosi tacno jedan umetak i pocinje prelomom reda;
   ;;  poravnanje kolone je posao prevodioca, isto kao kod tras.*.
   ("info.zaglavlje"      . "\n--- ELEMENT DATA:  %1 ---")
   ;;  Natpis nad sirovim zapisom.  Bez njega poslednji red izgleda kao
   ;;  neprevedeni ostatak, a on je snimak onoga sto stoji u crtezu:
   ;;  kljuc vrste, status i kodovi domena su ZAMRZNUTI i ne prevode se
   ;;  nigde -- svaki od njih vec ima svoj prevedeni red iznad.
   ("info.zapis"          . "\n\n  record as stored in the drawing (codes, not translated):")
   ("info.p.id"           . "\n  id            %1")
   ("info.p.kabl"         . "\n  cable         %1")
   ("info.p.cevcica"      . "\n  tube          %1")
   ("info.p.ucevcici"     . "\n  in tube       %1")
   ("info.p.rbr"          . "\n  ordinal       %1")
   ("info.p.boja"         . "\n  color         %1")
   ("info.p.status"       . "\n  status        %1")
   ("info.p.zavrseci"     . "\n  ends          %1")
   ("info.p.prolaznost"   . "\n  continuity    %1")
   ("info.p.namena"       . "\n  purpose       %1")
   ("info.p.natpis"       . "\n  tag           %1")
   ("info.p.kategorija"   . "\n  category      %1")
   ("info.p.ugao"         . "\n  angle         %1")
   ("info.p.colorcode"    . "\n  color code    %1")
   ("info.p.lanac"        . "\n  chain         %1")
   ("info.p.opis"         . "\n  description   %1")
   ("info.p.vrsta"        . "\n  fiber type    %1")
   ("info.p.duzina"       . "\n  lengths       %1")
   ("info.p.oznaka"       . "\n  label         %1")
   ("info.p.model"        . "\n  model         %1")
   ("info.p.kapacitet"    . "\n  capacity      %1")
   ("info.p.zauzeto"      . "\n  used          %1")
   ("info.p.konektor"     . "\n  connector     %1")
   ("info.p.letva"        . "\n  rack, module  %1")
   ("info.p.montaza"      . "\n  mounting      %1")
   ("info.p.adresa"       . "\n  address       %1")
   ("info.p.spliter"      . "\n  splitter      %1")
   ("info.p.tip"          . "\n  type          %1")
   ("info.p.mesto"        . "\n  location      %1")
   ("info.p.broj"         . "\n  number        %1")
   ("info.p.odnos"        . "\n  ratio         %1")
   ("info.p.gubitak"      . "\n  loss dB       %1")
   ("info.p.izlaz"        . "\n  output        %1")
   ("info.p.port"         . "\n  port          %1")
   ("info.p.portovi"      . "\n  PON ports     %1")
   ("info.p.korisnik"     . "\n  subscriber    %1")
   ("info.p.olt"          . "\n  OLT           %1")
   ("info.p.ont"          . "\n  ONT           %1")
   ("info.p.duzinam"      . "\n  length m      %1")
   ("info.p.vlaknoa"      . "\n  fiber A       %1")
   ("info.p.vlaknob"      . "\n  fiber B       %1")
   ("info.p.nacin"        . "\n  joint         %1")
   ("info.p.nastavak"     . "\n  closure       %1")
   ("bom.pitaj.tacka"      . "\nTable insertion point (top left): ")
   ("bom.tabela.naslov"    . "BILL OF MATERIALS")
   ;; --- FQBUDZET (blok 4.2) ---
   ;;
   ;;  Redovi izvestaja su cele niske sa natpisom UNUTRA, jer poravnanje
   ;;  kolone "=" zavisi od duzine natpisa, a ona nije ista u dva jezika:
   ;;  "konektori" ima 9 slova, "connectors" 10.  Uvlaka do prve cifre je
   ;;  13 znakova u oba jezika -- ko menja natpis, menja i razmake.
   ("budz.tok.vlakno"      . "Fiber")
   ("budz.tok.rucno"       . "Manual")
   ("budz.pitaj.izvor"     . "\nWhere from [%1/%2] <%3>: ")
   ("budz.pitaj.vlakno"    . "\nPick a fiber of the route: ")
   ("budz.pitaj.km"        . "\nOLT-ONT route length in km <2.0>: ")
   ("budz.pitaj.varenja"   . "\nNumber of splices <8>: ")
   ("budz.pitaj.konektori" . "\nNumber of connector pairs <4>: ")
   ("budz.pitaj.spl1"      . "\nFirst splitter stage K (0 if none) <4>: ")
   ("budz.pitaj.spl2"      . "\nSecond splitter stage K (0 if none) <8>: ")
   ("budz.pitaj.talasna"   . "\nWavelength [%1] <%2>: ")
   ("budz.izcrteza"        . "\nFrom the drawing: %1, splices %2, connector pairs %3%4")
   ("budz.bez.zavrsetka"   . "\n  The fiber has no termination recorded, check the ODF and FDH.")
   ("budz.bez.vrste"       . "\n  The fiber has no type recorded -- the drawing predates 1.0.0.\n  FQVRSTA sets it; until then I ask here.")
   ("budz.rucno"           . "\nNo fiber picked, switching to manual entry.")
   ("budz.naslov"          . "\n--- OPTICAL BUDGET, %1, %2 nm ---")
   ("budz.tabela.naslov"   . "OPTICAL BUDGET, %1, %2 nm")
   ("budz.upisano"         . "\nBudget written into the drawing.")
   ("budz.red.vlakno"      . "\n  fiber      %1 km x %2 dB/km = %3 dB")
   ("budz.red.varenja"     . "\n  splices    %1 x %2 = %3 dB")
   ("budz.red.konektori"   . "\n  connectors %1 x %2 = %3 dB")
   ("budz.red.spliter"     . "\n  splitter 1:%1  = %2 dB")
   ("budz.red.rezerva"     . "\n  margin     %1 dB")
   ("budz.red.ukupno"      . "\n  TOTAL      %1 dB")
   ("budz.klasa"           . "\n  class %1 (%2 dB): %3")
   ("budz.prolazi"         . "passes")
   ("budz.neprolazi"       . "does NOT pass")
   ;; --- FQTRASA (blok 4.2) ---
   ("tras.naslov"          . "\n--- FIBER ROUTE ---")
   ("tras.kabl"            . "\n  cable       %1%2")
   ("tras.vlakno"          . "\n  fiber       %1, tube %2, color %3, ordinal %4")
   ("tras.namena"          . "\n  purpose     %1,  status %2%3")
   ("tras.deonice"         . "\n  segments    ")
   ("tras.varenja"         . "\n  splices     %1")
   ("tras.unastavcima"     . "   in closures: ")
   ("tras.zavrseci"        . "\n  ends        ")
   ("tras.zavrseci.nema"   . "\n  ends        none, the fiber is not terminated anywhere")
   ("tras.konektori"       . "\n  connectors  %1 connector pairs")
   ("tras.oznaka"          . "\n  The fiber is highlighted in the drawing.  The highlight clears\n  on the next FQTRASA -- including when you press Esc at the fiber prompt.\n  FQBUDZET can take these numbers over, the Fiber option.")
   ;; --- kabl, lomovi, namena, poravnanje (blok 4.3) ---
   ("opste.tok.da"         . "Yes")
   ("opste.tok.ne"         . "No")
   ("opste.vodoravno"      . "horizontal")
   ("opste.uspravno"       . "vertical")
   ("opste.drag.hint"      . "%1  [click places, O for osnap]")
   ("opste.osnap.tacka"    . "\n  Osnap: pick a point: ")
   ("opste.snap.ramova"    . "\n  Snapping to the first connector, frames in the drawing: %1.")
   ("opste.pregled.ne.vise" . "\n  Preview not available, plain point entry.")
   ("kabl.velik"           . "\nA %1x%2 cable has %3 fibers, drawing may take a while. Continue? [%4/%5] <%4>: ")
   ("kabl.uhvacen"         . "\n  Caught connector %1, angle %2.")
   ("kabl.pitaj.cevcica"   . "\nNumber of tubes <2>: ")
   ("kabl.pitaj.povlakn"   . "\nFibers per tube <6>: ")
   ("kabl.pitaj.tip"       . "\nCable type, empty for none: ")
   ("kabl.pitaj.oznaka"    . "\nCable label <auto>: ")
   ("kabl.povuci.duzinu"   . "\nDrag the cable length   [click accepts, Enter keeps %1]")
   ("kabl.povlacenje.ne"   . "\n  Dragging not available, the entered length stands.")
   ("kabl.kratak.natpis"   . "\nThe cable is too short for a label at both ends, only the left one stays.")
   ("kabl.nacrtan"         . "\nCable %1 = %2 fibers, %3, angle %4%5")
   ("kabl.redovi.mreza"    . ", rows follow the reference cable grid")
   ("kabl.polozaj.ormar2"  . "\nPosition taken from the cabinet.")
   ("kabl.nepoznata.kat"   . "\nUnknown category: %1")
   ("kabl.tip.dopisan"     . "\nNew cable type added to the catalogue: %1.  FQKABLSAVE stores it permanently.")
   ("kabl.dijalog.ne"      . "\nCannot open the cable dialog.")
   ("odo.raspored"         . "\nLayout of the cable that will enter the cabinet.")
   ("odo.pitaj.povlakn"    . "\n  Fibers per tube <12>: ")
   ("odo.pitaj.cevcica"    . "\n  Number of tubes <%1>: ")
   ("lom.nema.duzine"      . "\nThe cable path has no segment with a length.")
   ("lom.deo.kratak"       . "\nSegment %1 is too short for a bundle of %2 fibers: fiber %3 would fold back on it.\nExtend that segment or drop one bend.\nNothing was drawn.")
   ("lom.prvi.kratak"      . "\nThe first segment is too short for labels (%1, needs %2), that end has none.")
   ("lom.zadnji.kratak"    . "\nThe last segment is too short for labels (%1, needs %2), only the starting end keeps them.")
   ;;  Tacka je NA KRAJU, iza %7, a ne iza ugla.  Sa %6.%7 je recenica
   ;;  zavrsavala pre poslednje klauze: "ends at angle 0., rows follow".
   ("lom.nacrtan"          . "\nCable %1 = %2 fibers, %3%4, total %5, ends at angle %6%7.")
   ("lom.povuci"           . "\nDrag the cable: a click bends at a right angle, Enter finishes, U undoes a bend, O for osnap.")
   ("lom.deo.bezduz"       . "\n  That segment has no length, click farther from the last bend.")
   ("lom.nema.loma"        . "\n  No bend to undo.")
   ("lom.osnap.tacka"      . "\n  Osnap: pick the bend point: ")
   ("lom.tacke"            . "\nBend points, Enter finishes the cable.")
   ("lom.pitaj.lom"        . "\n  Bend or end (%1), Enter finishes: ")
   ("lom.duzina.izputanje" . "\nCable with bends.  The length is not entered, it comes from the path.")
   ("por.treba.kucista"    . "\nAligning by a frame also needs fq-kucista.lsp.")
   ("por.ponisteno"        . "\nAlignment cleared.")
   ("por.sa.rama"          . "\nAlignment taken from frame %1, angle %2.")
   ("por.prvi.konektor"    . "\nThe next cable starts exactly at the first connector, with no point to pick.")
   ("por.prvi.red"         . "\nThe next cable lies in the first row of the frame, the position along the cable is picked.")
   ("por.ogledalo"         . "\n%1 is mirrored: its ports face away from the cable side, so a cable cannot start from it. Snap the END of a cable onto its connectors instead.")
   ("por.pitaj"            . "\nAlign by [%1/%2] <%3>: ")
   ("por.tok.mreza"        . "Grid")
   ("por.tok.pocetak"      . "Start")
   ("por.redovi.ne"        . "\nCannot read the rows of that cable.")
   ("por.sa.vlakna"        . "\nAlignment taken from fiber %1 (cable %2, ordinal %3), angle %4.")
   ("por.mreza"            . "\nGrid: %1 rows available, the new cable lies row for row.")
   ("por.samo.prvi"        . "\nOnly the first row is taken, from there the natural pitch.")
   ("nam.nepoznata"        . "\nUnknown purpose: %1")
   ("nam.izaberi"          . "\nSelect fibers, purpose: %1")
   ("nam.promenjeno"       . "\nFibers changed: %1, purpose %2.")
   ("vrs.izaberi"          . "\nSelect fibers, type: %1 - %2")
   ("vrs.promenjeno"       . "\nFibers changed: %1, type %2.")
   ;; FQDUZINA.  "m" ostaje bez prevoda -- oznaka jedinice po SI je ista
   ;; na oba jezika, a prevedena bi bila greska, ne prevod.
   ("duz.pitaj.vlakno"     . "\nFiber of the cable being measured: ")
   ("duz.prolazi"          . "\nThe fiber runs through: %1")
   ("duz.pitaj.duzina"     . "\nReal length of %1 in meters <%2>: ")
   ("duz.nepoznata"        . "unknown")
   ("duz.negativna"        . "\n%1: length cannot be negative, skipped.")
   ("duz.upisano"          . "\n%1 = %2 m, written to %3 fibers.")
   ("duz.nista"            . "\nNothing written.")
   ;; Cetiri oblika istog pitanja: sa tipom kabla u natpisu i bez njega,
   ;; a od svakog po jedan kad poravnanje vec vazi (tada se red ne bira).
   ("kabl.pitaj.tacka"     . "\nInsertion point: ")
   ("kabl.pitaj.polozaj"   . "\nPick the position, the row is taken over: ")
   ("kabl.pitaj.tacka.tip" . "\n%1 - insertion point: ")
   ("kabl.pitaj.polozaj.tip" . "\n%1 - pick the position, the row is taken over: ")
   ;; Tri kljuca, dve razlicite niske: engleski ima jedninu i mnozinu,
   ;; srpski tri oblika.  Koji se uzima bira fq:lomrec, jer to zavisi od
   ;; broja -- a broj tabela ne vidi.
   ("lom.broj.1"           . "%1 bend")
   ("lom.broj.2"           . "%1 bends")
   ("lom.broj.5"           . "%1 bends")
   ;; --- ODO, ODF, nastavak, spliter, OLT/ONT (blok 4.4) ---
   ("opste.tok.kabl"       . "Cable")
   ("opste.tok.samostalno" . "Standalone")
   ("opste.pitaj.kaci"     . "\n%1 attaches to [%2/%3] <%4>: ")
   ("odo.nacrtan"          . "\n%1 (%2)%3%4, %5%6")
   ("odo.portovi"          . ", %1 ports used (%2 down to %3)")
   ("odo.portovi.nema"     . ", no port is taken")
   ("odo.visi"             . ", %1 more fibers hang in the cabinet")
   ("odo.pitaj.oznaka"     . "\nCabinet label <auto>: ")
   ("odo.pitaj.adresa"     . "\nAddress and number: ")
   ("odo.pitaj.kapacitet"  . "\nCabinet capacity <48>: ")
   ("odo.pitaj.model"      . "\nCabinet model <none>: ")
   ("odo.pitaj.portovi"    . "\nNumber of ports used <%1>: ")
   ("odo.pitaj.tacka"      . "\nPoint of the FIRST cabinet port: ")
   ("odo.poravnanje"       . "\nAlignment set on cabinet %1.")
   ("odo.sledeci"          . "\nThe next cable starts at the first port, layout %1x%2, with no point to pick.")
   ("odf.nacrtan"          . "\nODF %1  %2%3, %4 of %5 connectors used, %6")
   ("odf.pitaj.kapacitet"  . "\nODF capacity <%1>: ")
   ("odf.pitaj.objekat"    . "\nSite name, goes after OR <NAME>: ")
   ("odf.pitaj.konektor"   . "\nConnector type <%1>: ")
   ("odf.pitaj.model"      . "\nODF type and model <ODF 19\" %1x%2>: ")
   ("odf.pitaj.letva"      . "\nRack and module, optional: ")
   ("odf.pitaj.konektori"  . "\nNumber of connectors used <%1>: ")
   ("odf.pitaj.tacka"      . "\nPoint of the FIRST ODF connector: ")
   ("odf.poravnanje"       . "\nAlignment set on ODF %1.")
   ("odf.sledeci"          . "\nThe next cable starts at the first connector, layout %1x%2, with no point to pick.")
   ("nast.nacrtan"         . "\nClosure %1 (%2), width %3%4, %5")
   ("nast.info"            . "\nClosure: %1   frame %2 .. %3, middle %4%5")
   ("nast.info.izvan"      . ", fiber end %1 outside the frame")
   ("nast.paznja.red"      . "\n  CAUTION: the fiber row is %1 outside the frame height. Check that this really is that closure.")
   ("nast.nema.pod.uglom"  . "\nThe drawing has no closure at that angle.")
   ("nast.povuci.ivicu"    . "\nRight edge of the closure   [click accepts, Enter keeps width %1]")
   ("nast.pitaj.ivica"     . "\nRight edge of the closure: ")
   ("nast.pitaj.leva"      . "\nLeft edge of the closure: ")
   ("nast.isti.kabl"       . "\nCable %1, the same one as for the previous closure.")
   ;;  Nov kabl na kraju nastavka.  Prvi red ide PRE crtanja, iz
   ;;  fq:nastuvod: ceo kabl se pomera, pa i natpisi nastaju izvan rama.
   ;;  Druga dva idu posle crtanja, iz fq:nastsiriend.
   ("nast.kabl.uvod"       . "\n  The cable starts at closure %1; moved %2 along the cable.")
   ("nast.siri"            . "\n  Closure %1 takes the new cable, %2 fibers%3.")
   ("nast.siri.ram"        . "; the frame has been widened")
   ("nast.nije.prosireno"  . "\n  The closure at the cable end was not widened: ")
   ;;  Ram nastavka crta projektant, pa jedino on moze i da ga popravi:
   ;;  natpisi stoje na apsolutnim tackama i skracivanje vlakna ih ne
   ;;  pomera, a ram se ne sme skupljati.  Kuciste ovo ne moze da ima.
   ("nast.natpisi.unutra"  . "\n  CAUTION: closure %1 has %2 tube marking(s) inside its frame. Draw the frame edge closer to the cable end, or move the cable.")
   ;;  Kabl sa lomovima.  Prvi pokusaj je ram SKRACIVAO na deonicu, i
   ;;  pucao je bas na kraju deonice, gde nastavci i idu -- ram bi
   ;;  ostao uzan koliko god se vukao.  Sada se prelom samo prijavi.
   ("nast.prelom"          . "\nThe closure reaches past a bend in the cable. The frame height is taken at its left edge.")
   ("nast.dijalog.ne"      . "\nCannot open the closure dialog.")
   ("nast.pitaj.oznaka"    . "\nClosure label <auto>: ")
   ("nast.pitaj.mesto"     . "\nWhere it sits, manhole or pole <%1>: ")
   ("nast.pitaj.broj"      . "\nManhole or pole number%1: ")
   ("spl.nacrtan"          . "\nSplitter %1 1:%2, loss %3 dB, %4")
   ("spl.u.kucistu"        . "\n  It ends on the connector column of a housing, but it is a SEPARATE element: only the first few outputs land on existing ports, the rest get no connectors, and the frame is not widened.\n  A splitter INSIDE a housing is drawn by FQSPLKUC - every output gets its own port and the frame grows to hold them.")
   ("spl.pitaj.k"          . "\nSplitter 1:K, enter K <32>: ")
   ("spl.pitaj.oznaka"     . "\nLabel <auto>: ")
   ("spl.pitaj.kraj"       . "\nEnd of the first output, at connector: ")
   ("spl.pitaj.kraj.oz"    . "\nSplitter %1 1:%2 - end of the first output, at connector: ")
   ("spl.hvat.izlaz"       . "\n  grip: end of the first output; I moves it to the input")
   ("spl.hvat.ulaz"        . "\n  grip: splitter input; I moves it back to the first output")
   ("spl.pitaj.ormar"      . "\nCabinet or box the splitter goes into: ")
   ("spl.treba.kucista"    . "\nA splitter inside a housing needs fq-kucista.lsp, which is not loaded.\nA standalone splitter still works.")
   ("olt.nacrtan"          . "\nOLT %1: %2 PON ports, %3")
   ("olt.pitaj.oznaka"     . "\nOLT label <auto>: ")
   ("olt.pitaj.portovi"    . "\nNumber of PON ports <16>: ")
   ("olt.pitaj.tacka"      . "\n%1  %2 PON - end of the first PON port: ")
   ("ont.nacrtan"          . "\nONT %1 %2, %3")
   ("ont.pitaj.oznaka"     . "\nONT label <ONT>: ")
   ("ont.pitaj.korisnik"   . "\nSubscriber / flat: ")
   ("ont.pitaj.tacka"      . "\nONT - end of the drop, at connector: ")
   ("rez.nacrtan"          . "\nSlack %1 m, %2")
   ("rez.zaokruzeno"       . "  (entered %1, rounded to whole metres)")
   ("rez.pitaj.tacka"      . "\nSlack %1 m - point: ")
   ;; Naziv elementa kao umetak u zajednicko pitanje "%1 se kaci".  Ovo
   ;; je PRIKAZ, ne kljuc: ODO se na engleskom zove FDH.  Kljuc "ODO" u
   ;; xdata ostaje zauvek, isto kao "IPAN" kad se ormar preimenovao.
   ("odo.naziv"            . "FDH")
   ("odf.naziv"            . "ODF")
   ("odo.pitaj.vlakno"     . "\nA fiber of the cable, click near the end where the cabinet stands: ")
   ("odf.pitaj.vlakno"     . "\nA fiber of the cable, click near the end where the ODF stands: ")
   ;; --- spajanje, splajs, odvod, presecanje (blok 4.5) ---
   ("opste.nagore"         . "upward")
   ("opste.nanize"         . "downward")
   ("spoj.gotovo"          . "\nFibers joined.")
   ("spoj.paznja.stepenik" . "\n  CAUTION: the ends are not in the same row, the joint keeps a step.")
   ("spoj.gusto"           . "\n  %1 joint(s) could not be placed without overlap, so they share part of a row or column.  Two fibers that SWAP rows cannot be separated in a rectilinear drawing; for the rest, a wider closure frame helps.")
   ("spl2.nema.putanje"    . "  the fiber has no path")
   ("spl2.nema.elementa"   . "\n  There is no closure or housing at that spot.")
   ("spl2.postavljen"      . "  %1, splice%2")
   ("spl2.umestu"          . " in %1")
   ("spl2.misem"           . "\n  from now on the splice spot is picked with the mouse")
   ("spl2.sredina"         . "\n  from now on the splice goes to the middle of the element")
   ("spl2.ukupno"          . "\nSplices placed: %1")
   ("grp.kabl.a"           . "\nA: %1  %2 fibers, starting at %3")
   ("grp.kabl.b"           . "\nB: %1  %2 fibers, starting at %3")
   ("grp.pitaj.koliko"     . "\nHow many fibers to join <12>: ")
   ("grp.pitaj.korak"      . "\nStep, 1 joins in order, 2 skips every other <1>: ")
   ("grp.uspravni"         . "\nPairs with a vertical end: %1, the joint runs at a right angle to the branch column.")
   ("grp.paznja.redovi"    . "\nCAUTION: %1 of %2 pairs do not lie in the same row.")
   ("grp.raspored"         . "\nThe two cables do not share the tube layout, so those fibers will have a step.")
   ("grp.savet1"           . "\nIf you do not want that, stop, delete cable B and lay it again through")
   ("grp.savet2"           . "\nthe Align with cable button, Grid option.")
   ("grp.otkazano"         . "\nCancelled, nothing was joined.")
   ("grp.nema.para"        . "\n  no pair for fiber %1")
   ("grp.spojeno"          . "\nPairs joined: %1, step %2%3%4")
   ("grp.unastavku"        . ", closure %1")
   ("grp.stepenik"         . ", with a step: %1")
   ("odv.pitaj.koliko"     . "\nHow many fibers go into the branch <6>: ")
   ("odv.smer"             . "\nBranch %1, the bend is computed, step %2, from coordinate %3")
   ("odv.nema.vlakna"      . "\n  no fiber %1")
   ("odv.presk.uspravno"   . "\n  fiber %1 skipped, its end is not horizontal")
   ("odv.ukupno"           . "\nFibers branched off: %1.")
   ("odv.dalje"            . "\nA closure and joining now go on that end.")
   ("prs.element"          . "\n  %1 %2, frame %3 .. %4")
   ("prs.paznja.red"       . "\n  CAUTION: the fiber row is %1 outside the frame height. Check that this really is that element.")
   ("prs.nema.elementa"    . "\nThe drawing has no closure or housing at that spot.")
   ("prs.ne.mogu"          . "\n  cannot cut %1 at %2")
   ("prs.tom.mestu"        . "that spot")
   ("prs.jedno"            . "\n  %1%2%3")
   ("prs.preseceno"        . " cut")
   ("prs.uvedeno"          . " led in and terminated")
   ("prs.umestu"           . " in %1")
   ("prs.pitaj.ugao2"      . "\nSecond corner, drag across the fibers: ")
   ("prs.uprozoru"         . "\nFibers in the window: %1")
   ("prs.prazan.prozor"    . "\n  no fibers in the window")
   ("prs.ukupno"           . "\nFibers cut: %1%2%3")
   ("prs.oba.kraka"        . ", %1 of them with both legs")
   ("prs.obrisano.var"     . ", splices deleted in the gap: %1")
   ("pro.skinuto"          . "  %1, points removed: %2")
   ("pro.upisano"          . "  %1 recorded as through")
   ("pro.spojeno"          . "  joined into a straight fiber")
   ("pro.ukupno"           . "\nThrough fibers: %1%2%3")
   ("pro.ukupno.tacke"     . ", points removed: %1")
   ("pro.ukupno.krakovi"   . ", legs joined: %1")
   ("grp.pitaj.svejedno"   . "\nJoin anyway? [%1/%2] <%3>: ")
   ;; --- katalog, color code, lejeri, paleta, FQINFO (blok 4.6) ---
   ("opste.lwdisplay"      . "\nLine weight display turned on (LWDISPLAY).")
   ("opste.ucs.1"          . "\nFiberQ draws only in the world coordinate system (WCS).")
   ("opste.ucs.2"          . "\n  Type  UCS  then  W  then Enter, and repeat the command.")
   ("opste.ucs.3"          . "\n  Preview, bill of materials and budget work either way.")
   ("opste.nije.broj"      . "\n  \"%1\" is not a number.  Decimals take a comma or a dot.")
   ("opste.nije.vlakno.kabla" . "\nThe selected element is not a fiber from a cable.")
   ("kbl.sacuvan"          . "\nCable catalogue saved to %1")
   ("kbl.ne.sacuvan"       . "\nCannot save the cable catalogue to %1")
   ("cc.pitaj.boja"        . "\nName of the new color: ")
   ("cc.boja.dodata"       . "\nColor %1 added, ACI %2.")
   ("cc.editor.ne"         . "\nCannot open the standards editor.")
   ("cc.aktivan"           . "\nActive color code: %1")
   ("cc.primenjen"         . "\nStandard applied to %1 layers.")
   ("kabl.izabran"         . "\nCable %1  %2, %3 fibers, angle %4 degrees, end at %5.")
   ("leg.upisana"          . "\nLegend written.")
   ("pal.ne.mogu"          . "\nCannot open the palette.")
   ("pal.greska"           . "\nError in command %1: %2")
   ("pal.greska.alert"     . "FiberQ, error in command %1:\n\n%2")
   ("info.sema"            . "\n  fq-sema.lsp     loaded")
   ("info.ucitan"          . "loaded")
   ("info.ucitana"         . "loaded")
   ("info.nije.ucitana"    . "not loaded")
   ("info.kucista"         . "\n  fq-kucista.lsp  %1")
   ("info.kucista.nema"    . "NOT loaded -- no FAT, patch panel or MDU")
   ("info.traka"           . "\n  ribbon          %1")
   ("info.cad"             . "\n  CAD             %1   %2")
   ("info.cc"              . "\n  color code      %1")
   ("info.katalog"         . "\n  catalogue       %1")
   ("info.katalog.podr"    . "\n  catalogue       built in, without models")
   ("info.kbl"             . "\n  cable catalogue %1")
   ("info.kbl.podr"        . "\n  cable catalogue built in")
   ("info.ccfajl"          . "\n  color code file %1")
   ("info.ccfajl.nema"     . "\n  color code file none, only the built-in standards")
   ;;  Umetak je (car (fq:ccwpaths)) -- putanja za BOJE i nista drugo.
   ;;  Do 22.08.2026 je red glasio "data is written to %1", a katalog
   ;;  kucista i katalog kablova pisu se u <profil>\Support\, dakle u
   ;;  drugi folder.  Ovi redovi postoje da bi se na prijavu "izgubio mi
   ;;  se katalog" moglo odgovoriti nesto pametno, pa je red koji tada
   ;;  upucuje na pogresan folder gori nego da ga nema.
   ("info.pisu"            . "\n  color codes are written to %1")
   ("info.pisukat"         . "\n  housing catalogue is written to %1")
   ("info.pisukbl"         . "\n  cable catalogue is written to %1")
   ("pomoc.otvaram"        . "\n  Opening the user guide: %1")
   ("pomoc.nema"           . "\n  User guide not found.  It is installed in the FiberQ.bundle folder, beside LICENSE.")
   ("pomoc.nesme"          . "\n  The system would not open it.  Open the file above by hand.")
   ("zak.stanje.zakljucan" . "locked")
   ("zak.stanje.zamrznut"  . "frozen")
   ("zak.stanje.ugasen"    . "off")
   ("zak.razlog"           . " -- the layer is %1")
   ("zak.razlog.nepoznat"  . " -- reason unknown")
   ("zak.upis"             . "\nCAUTION: the record did not go onto layer %1%2.\n  It IS drawn, but the bill of materials, the budget and FQTRASA will NOT see it.\n  Type U to undo the whole action, unlock the layer, then repeat the command.")
   ("zak.brisanje"         . "\nCAUTION: the delete did not go through on layer %1%2.\n  The old drawing is unchanged.\n  Type U to undo the whole action, unlock the layer, then repeat the command.")
   ;; --- fq-kucista.lsp (blok 4.6) ---
   ("kuc.ram.ne"           . "\nThe box frame was not drawn, so the record was not written.")
   ("kuc.spl.nestaje.kutija" . "\nCAUTION: a 1:%1 splitter does not fit a box of %2 connectors, drawing %3 outputs.")
   ("kuc.spl.nestaje.ormar"  . "\nCAUTION: a 1:%1 splitter does not fit %2 ports with %3 taken, drawing %4 outputs.")
   ("zok.nacrtan"          . "\n%1%2%3  %4x%5%6, %7")
   ("zok.spliter"          . ", splitter 1:%1 from connector %2 to connectors 1-%3")
   ("zok.iskorisceno"      . ", %1 of %2 used")
   ("pp.nacrtan"           . "\n%1%2%3%4 connectors, %5 of %6 used, %7")
   ("pp.moduli"            . ", %1 modules of %2")
   ("pp.jedan"             . ", %1")
   ("odospl.nacrtan"       . "\n%1 (%2)%3, splitter 1:%4 from port %5 to ports %6-%7, %8%9")
   ("kuc.nepoznat.crtac"   . "\nUnknown drawer for %1.")
   ("kuc.nema.rama"        . "\nWarning: cannot find frame %1 to record it as %2.")
   ("kuc.pitaj.nakonektore" . "\nHow many fibers go onto connectors <%1>, at most %2, 0 for none: ")
   ("kuc.nema.kabla"       . "\nThe drawing has no cable yet, placing standalone.")
   ("kuc.pitaj.samostalno" . "\nPlace standalone, without a cable [%1/%2] <%3>: ")
   ("kuc.poravnanje"       . "\nAlignment set on %1. The next cable starts at %2")
   ("kuc.por.vlakno"       . "the incoming fiber.")
   ("kuc.por.konektor"     . "the first connector.")
   ("kuc.dijalog.ne"       . "\nCannot open the housing dialog.")
   ("kuc.nepoznata.vrsta"  . "\nUnknown housing type: %1")
   ("kuc.montaza"          . "\nMounting for %1: %2")
   ("kuc.pitaj.kapacitet"  . "\nCapacity <%1>: ")
   ("kuc.pitaj.model"      . "\nModel <%1>: ")
   ("kuc.model.bez"        . "none")
   ("kuc.pitaj.montaza"    . "\nMounting <%1>: ")
   ("kuc.pitaj.letva"      . "\nRack and module <%1>: ")
   ("kuc.pitaj.moduli"     . "\nNumber of modules <1>: ")
   ("kuc.pitaj.adresa"     . "\nAddress or location: ")
   ("kuc.pitaj.odnos"      . "\nSplitter ratio 1:K, enter K <%1>: ")
   ("kuc.pitaj.spliter"    . "\nSplitter inside the %1 [%2/%3] <%4>: ")
   ("kuc.kutije"           . "box")
   ("kuc.ormara"           . "cabinet")
   ("kuc.nije.ram"         . "\nThat is not a housing frame.")
   ("kuc.klikni.ram"       . "\nClick the rectangle of an ODF, patch panel, cabinet or box.")
   ("kuc.pitaj.dodaj"      . "\nHousing the fiber is added to: ")
   ("kuc.ugao.nema"        . "\n%1: cannot read the frame angle.")
   ("kuc.ugao.razlika"     . "\n%1 is drawn at %2 degrees, and that cable runs at %3.\nClick a fiber of a cable in the same orientation as the housing.")
   ("kuc.ima.spliter"      . "\n%1 holds a splitter (%2): every output is already drawn,\nso there is nothing to add and the frame is not redrawn.")
   ("kuc.spl.rastegnut"    . "\n%1 holds a splitter (%2), so it is not redrawn - the frame is only stretched over the bundle of %3 fibers.\n  Ports, splitter body and fan stay where they are; fibers without a port are spare.")
   ("spl.dopisano"         . "\n%1 holds a splitter (%2): %3 fiber(s) connected to ports %4 to %5, %6 of %7 taken.\n  Splitter body, fan and every existing port stay untouched - only the new ports are added.")
   ("kuc.samo.ram"         . "\n%1: the frame is stretched over the whole bundle, connections are left alone.")
   ("kuc.pitanje.otkazano" . "\n  Question cancelled - connections stay as they are, the frame still follows the cable.")
   ("kuc.naslov.ostaje"    . "\n%1: another housing sits right above the frame, so the labels above it stay.\n  Whatever doubles up - title, model - delete the upper copy by hand.")
   ("kuc.montaza.ostaje"   . "\n%1: another housing sits right below the frame, so the labels below it stay.\n  Whatever doubles up, delete the lower copy by hand.")
   ("kuc.nije.obrisan"     . "\n%1: the old drawing was not deleted (%2 of %3 parts), so the new one was NOT drawn.\n  Unlock the housing layers and repeat FQDODAJ.")
   ("dod.pitaj.koliko"     . "\nHow many more fibers to connect <%1>, at most %2, 0 only widens the frame: ")
   ("dod.nema.sta"         . "\n%1: nothing left to connect, the frame only widens.")
   ("dod.pun"              . "\n%1: all %2 connectors are in use; the rest of the bundle stays in the cassette.\n  A larger module, or one more module of the panel, takes them (FQKUC).")
   ("dod.rezultat"         . "\n%1: %2")
   ("dod.povezano"         . "%1 more connected, %2 of %3 connectors in total.")
   ("dod.rasireno"         . "frame covers the bundle of %1 fibers, on connectors %2 of %3.")
   ("dod.sva.vezana"       . "\nEvery fiber of that cable is already connected to %1.")
   ("dod.nijedno"          . "\nNo fiber of that cable passes through %1.\nCheck that you clicked the same cable, and the same end, as when it was placed.")
   ("dod.ne.zavrsavaju"    . "\nThose fibers do not end at %1.\nClick a fiber at the cable end where the housing stands.")
   ("por.nije.ni"          . "\nThat is neither a fiber nor a housing or closure frame.")
   ("por.klikni"           . "\nClick a fiber, or the rectangle of an ODF, cabinet, box or closure.")
   ("osp.nije.ormar"       . "\n%1 is neither a cabinet nor a box.")
   ("osp.kutija.savet"     . "\nA splitter goes into a cabinet (FDH) or a box (FAT). None is drawn into a patch panel rack, and a closure has no connector column for the outputs to land on.")
   ("osp.kutija.vise"      . "\n%1 already has %2 fibers on connectors, and a box with a splitter is built around a single incoming fiber.\nDraw the box with the splitter from the start, or bring only the feeding fiber into it.")
   ("osp.prazan"           . "\n%1 has no cable in it, so the splitter is fed from the first connector of the frame. No fiber is clicked.")
   ("osp.vec.ima"          . "\n%1 already has a splitter inside.")
   ("osp.nema.porta"       . "\n%1 has no port taken, so the splitter has nothing to feed from.")
   ("osp.prvo.kabl"        . "\nBring the cable in first, then the splitter.")
   ("osp.pun"              . "\n%1 is full: all %2 ports are taken.")
   ("osp.ugao"             . "\n%1 is drawn at %2 degrees, and that cable at %3 degrees.")
   ("osp.ne.zavrsavaju"    . "\nThose fibers do not end at %1.\nClick a fiber at the cable end where the cabinet stands.")
   ("osp.pitaj.port"       . "\nPort the splitter feeds from <%1>: ")
   ("osp.dodat"            . "\n%1: splitter added from port %2, %3 of %4 ports in total.")
   ("izv.nije.ram"         . "\nThat is not a housing or closure frame.")
   ("izv.klikni"           . "\nClick the rectangle of an ODF, patch panel, cabinet, box or closure.")
   ("izv.pitaj.ram"        . "\nHousing or closure the cable leaves from: ")
   ("izv.snop.siri"        . "\nCAUTION: a bundle of %1 fibers is wider than the frame, the first verticals run out to its left.")
   ("izv.nema.temena"      . "\nThat frame has no corners.")
   ("izv.ogledalo"         . "\n%1 is mirrored, and a drop cable would run into its body. Draw the drop with FQLOM or FQODVOD instead.")
   ("izv.iz.nastavka"      . "\nBranch out of closure %1, drawn at %2 degrees.")
   ("izv.vec.ima"          . "\n  The frame already holds a branch, the new one goes to its left.")
   ("izv.ram.prosiren"     . "\n  The closure frame has been widened.")
   ("izv.savet.spoji"      . "\n  Branch fibers and incoming fibers are joined with the Join or Join group button.")
   ("izv.kutija.spliter"   . "\n%1 has a splitter, so no cable leaves it further.")
   ("izv.klikni.kuc"       . "\nClick the rectangle of a cabinet, box or module.")
   ("izv.iz.kucista"       . "\nBranch out of %1, the housing is drawn at %2 degrees.")
   ("izv.pitaj.lakat"      . "\nBranch fibers inside the housing [%1/%2] <%3>: ")
   ("izv.tok.lakat"        . "Elbow")
   ("izv.tok.prava"        . "Straight")
   ("izv.bez.lakta"        . "\n  The fibers do not reach the connector column, so the frame stays as it is and nothing is connected.")
   ("izv.nacrtan"          . "\nBranch %1  %2 out of %3, %4 fibers, length %5.")
   ("izv.donji.kraj"       . "\n  The lower end is an ordinary cable end: a closure, splitter or the next housing goes there.")
   ("ops.sada.pise"        . "\nIt now reads: %1")
   ("ops.pitaj.opis"       . "\nFiber description, empty deletes: ")
   ("ops.nije.obrisan"     . "\nThe old description was not deleted, so nothing was changed.\n  Unlock the layer the text sits on and repeat FQOPIS.")
   ("ops.obrisan"          . "\nDescription deleted.")
   ("ops.upisano"          . "\nWritten: %1")
   ("kat.sacuvan"          . "\nHousing catalogue saved to %1")
   ("kat.ne.sacuvan"       . "\nCannot save the housing catalogue to %1")
   ("izv.prikljucivanje.ne" . "\n  Connecting failed: ")
   ;; --- editor color code standarda i promptovi kroz omotace (blok 4.7) ---
   ("cc.info.stanje"       . "Active: %1     selected: %2  (%3 colors)     nothing is permanent until you save")
   ("cc.info.izaberi.boju" . "Pick a color from the list of known colors.")
   ("cc.info.dodata"       . "Color %1 added as number %2.")
   ("cc.info.prazan"       . "The standard has no colors.")
   ("cc.info.uklonjena"    . "Color removed from the standard.")
   ("cc.info.kraj"         . "Nowhere further to go.")
   ("cc.info.pomerena"     . "The color is now number %1.")
   ("cc.info.izaberi.mesto" . "Pick a slot in the standard and a color from the list.")
   ("cc.info.zamenjena"    . "Slot %1 is now %2.")
   ("cc.info.niz"          . "Type colors separated by commas, then click Apply list.")
   ("cc.info.ne.prepoznato" . "No color was recognised.")
   ("cc.info.upisano"      . "Colors written: %1%2")
   ("cc.info.nepoznate"    . "     not recognised: %1")
   ("cc.info.grupe"        . "Group labels stored with the standard.")
   ("cc.info.upisi.naziv"  . "Type a name into the Name field, then click the button.")
   ("cc.info.osnovni.pre"  . "The base standard cannot be renamed, use Copy.")
   ("cc.info.novi.naziv"   . "Type the new name into the Name field.")
   ("cc.info.preimenovano" . "Renamed to %1.")
   ("cc.info.osnovni.bri"  . "The base standard cannot be deleted.")
   ("cc.info.bar.jedan"    . "At least one standard must remain.")
   ("cc.info.potvrdi"      . "Click Delete once more to confirm deleting \"%1\".")
   ("cc.info.obrisan"      . "Standard deleted.")
   ("cc.info.prazan.aktivan" . "The standard has no colors, it cannot be the active one.")
   ("cc.info.aktivan"      . "The active standard is now %1.")
   ("cc.info.sacuvano"     . "Saved to %1")
   ("cc.info.ne.mogu"      . "Cannot write: %1")
   ("kuc.nije.prosireno"   . "\n  The housing at the cable end was not widened: ")
   ("kabl.pitaj.duzina"    . "\nLine length <%1>: ")
   ("opste.pitaj.tacka"    . "\nPoint: ")
   ("rez.pitaj.duzina"     . "\nSlack length in m <15>: ")
   ("por.pitaj.izbor"      . "\nPick a fiber, or a housing or closure frame, to align the new cable with: ")
   ("nast.pitaj.vlakno"    . "\nA fiber of the cable, click near the end that enters the closure: ")
   ("spoj.pitaj.prvo"      . "\nPick the first fiber, near the end you are joining: ")
   ("spoj.pitaj.drugo"     . "\nPick the second fiber, near the end you are joining: ")
   ("spoj.pitaj.mesto"     . "\nPick the joint location along the cable: ")
   ("spl2.pitaj.mesto"     . "\n  Pick the splice spot along the cable: ")
   ;;  Tokeni su bili ZAKUCANI u kodu na srpskom, a prompt preveden u
   ;;  bloku 4 -- pa je engleski prompt nudio [Point/Middle] i [Window],
   ;;  a initget primao samo "Tacka", "Sredina" i "Prozor".  Korisnik
   ;;  otkuca W, AutoCAD ga odbije, i izgleda kao da opcije nema.
   ;;  Nadjeno testiranjem 22.08.2026; do tada su grupno presecanje i
   ;;  oba nacina splajsa bili nedostupni na engleskom.
   ("spl2.tok.tacka"       . "Point")
   ("spl2.tok.sredina"     . "Middle")
   ("spl2.tok.prozor"      . "Window")
   ("spl2.pitaj.vlakno"    . "\nFiber the splice goes on [%1/%2/%3] (Enter to finish): ")
   ("grp.pitaj.a"          . "\nFIRST fiber of cable A, click near the end being joined: ")
   ("grp.pitaj.b"          . "\nFIRST fiber of cable B, click near the end being joined: ")
   ("odv.pitaj.prvo"       . "\nFIRST fiber of the branch, click near the end being branched: ")
   ("odv.pitaj.gde"        . "\nPick where the branch arrives, the row of the FIRST fiber: ")
   ("prs.pitaj.gde"        . "\nPick where the fiber is cut: ")
   ("prs.pitaj.ugao1"      . "\nFirst window corner, inside the closure or housing: ")
   ("prs.tok.prozor"       . "Window")
   ("prs.pitaj.vlakno"     . "\nFiber to cut, click it inside the closure or housing [%1] (Enter to finish): ")
   ("pro.pitaj.vlakno"     . "\nFiber that should be through (Enter to finish): ")
   ("pro.pitaj.krak"       . "\n  No splice on that fiber. Click the OTHER leg, anywhere along it, to join them into a straight fiber (Enter only records through): ")
   ("tras.pitaj.vlakno"    . "\nPick the fiber whose route interests you: ")
   ("info.pitaj.element"   . "\nPick a schematic element: ")
   ("leg.pitaj.tacka"      . "\nLegend insertion point (top left): ")
   ("kuc.pitaj.vlakno"     . "\nA fiber of the cable, click near the end where %1 stands: ")
   ("kuc.pitaj.dolazno"    . "\nPoint of the incoming fiber, %1: ")
   ("osp.pitaj.vlakno"     . "\nA fiber of the cable entering %1, click near the end at the cabinet: ")
   ("ops.pitaj.vlakno"     . "\nFiber to write a description on: ")
   ("cc.info.vec.postoji"  . "A standard with that name already exists.")
   ("cc.info.kopija"       . "Copy %1 created.")
   ("cc.info.prazan.nov"   . "Empty standard %1 created.")
   ("kuc.pitaj.prvo"       . "\nPoint of the first fiber, %1: ")

   ;; --- DCL, blok 5 -----------------------------------------------
   ;;
   ;;  Natpisi dijaloga.  DCL se pise u TEMPPREFIX pri SVAKOM otvaranju
   ;;  (fq:dclnast i ostali se zovu neposredno pre load_dialog), pa
   ;;  prebacivanje jezika hvata i vec otvaran dijalog, bez kesa.
   ;;
   ;;  Prevodi se samo `label`.  Kljuc (`key = "mod"`) NIKAD -- po njemu
   ;;  se polje nalazi iz koda, kroz get_tile i action_tile, i promasaj
   ;;  se ne vidi kao greska nego kao prazno polje.  test-lisp.ps1 to
   ;;  proverava.
   ;;
   ;;  Bez zavrsne dvotacke: DCL je sam dodaje uz edit_box i popup_list.

   ;; zajednicko vise dijaloga
   ("dcl.ok"               . "OK")
   ("dcl.odustani"         . "Cancel")
   ("dcl.zatvori"          . "Close")
   ("dcl.status"           . "Status")
   ("dcl.status.proj"      . "Designed")
   ("dcl.status.izv"       . "As-built")
   ("dcl.ispis"            . "Drawn in the drawing")
   ("dcl.kapacitet"        . "Capacity")
   ;; Zaglavlja grupa u listi kapaciteta.  Srpski ima tri oblika mnozine,
   ;; engleski dva -- ali kljuceva mora biti isto toliko u obe tabele, pa
   ;; se dva engleska poklapaju.  Vidi fq:kapzagl.
   ("dcl.kap.cev1"         . "-- %1 tube --")
   ("dcl.kap.cev24"        . "-- %1 tubes --")
   ("dcl.kap.cev5"         . "-- %1 tubes --")
   ("dcl.oznaka"           . "Label")
   ("dcl.orijentacija"     . "Orientation")
   ("dcl.ori.h"            . "Horizontal")
   ("dcl.ori.v"            . "Vertical")
   ("dcl.ori.gore"         . "Vertical up")
   ("dcl.ori.dole"         . "Vertical down")

   ;; naslovi prozora
   ("dcl.naslov.kabl"      . "FiberQ CAD  -  new cable")
   ("dcl.naslov.nast"      . "FiberQ CAD  -  closure")
   ("dcl.naslov.kuc"       . "FiberQ CAD  -  housing")
   ("dcl.naslov.cc"        . "FiberQ CAD  -  color code standards")
   ("dcl.naslov.pal"       . "FiberQ CAD  -  schematic elements")

   ;; nastavak
   ("dcl.nast.tip"         . "Type")
   ("dcl.nast.tn"          . "N  ordinary")
   ("dcl.nast.tl"          . "NL  latent")
   ("dcl.nast.ozn"         . "Label   (a number is enough)")
   ("dcl.nast.gde"         . "Where it sits")
   ("dcl.nast.broj"        . "No.")
   ("dcl.nast.serija"      . "Series")
   ("dcl.nast.vise"        . "Continue, ask for the next closure right away")
   ("dcl.nast.isti"        . "Same cable, do not pick a fiber again")

   ;; kabl
   ("dcl.kabl.tip"         . "Cable type")
   ("dcl.kabl.cc"          . "Color code")
   ("dcl.kabl.vrsta"       . "Fiber type")
   ("dcl.kabl.ozn"         . "Label, optional")
   ("dcl.kabl.duz"         . "Length, initial")
   ("dcl.kabl.dul"         . "Drag the length after the insertion point")
   ("dcl.kabl.lom"         . "Cable with bends, the path is clicked")

   ;; kuciste
   ("dcl.kuc.vrsta"        . "Type")
   ("dcl.kuc.model"        . "Model  (maker and type)")
   ("dcl.kuc.konektor"     . "Connector type")
   ("dcl.kuc.montaza"      . "Mounting")
   ("dcl.kuc.iskorisceno"  . "Used")
   ("dcl.kuc.letva"        . "Rack and module")
   ("dcl.kuc.modula"       . "Modules")
   ("dcl.kuc.adresa"       . "Address or location")
   ("dcl.kuc.spliter"      . "Splitter inside the box")
   ("dcl.kuc.kacenje"      . "Attaches to")
   ("dcl.kuc.na.kabl"      . "A cable")
   ("dcl.kuc.samostalno"   . "Nothing")
   ("dcl.kuc.nema.modela"  . "(none entered)")

   ;; color code
   ("dcl.cc.standardi"     . "Standards")
   ("dcl.cc.naziv"         . "Name")
   ("dcl.cc.novi"          . "New")
   ("dcl.cc.kopiraj"       . "Copy")
   ("dcl.cc.preimenuj"     . "Rename")
   ("dcl.cc.obrisi"        . "Delete")
   ("dcl.cc.aktivan"       . "Set as active")
   ("dcl.cc.redosled"      . "Order within the standard")
   ("dcl.cc.gore"          . "Up")
   ("dcl.cc.dole"          . "Down")
   ("dcl.cc.ukloni"        . "Remove")
   ("dcl.cc.zameni"        . "Replace with selected")
   ("dcl.cc.poznate"       . "Known colors")
   ("dcl.cc.dodaj"         . "Add to standard")
   ("dcl.cc.ostala"        . "Other color...")
   ("dcl.cc.niz"           . "The whole sequence at once, colors separated by commas")
   ("dcl.cc.primeni.niz"   . "Apply sequence")
   ("dcl.cc.prefiksi"      . "Label for fibers past the end of the table, by group")
   ("dcl.cc.primeni.pre"   . "Apply labels")
   ("dcl.cc.sacuvaj"       . "Save to file")
   ("dcl.cc.osnovni"       . "  base")

   ;; paleta
   ("dcl.pal.status"       . "Status of new elements")
   ("dcl.pal.keep"         . "Keep the palette open")
   ("dcl.pal.drag"         . "Cable preview with the mouse")
   ("dcl.pal.siri"         . "Cable widens the housing at its end")
   ("dcl.pal.snap"         . "Snap to the first connector of a frame")

   ;; natpisi koje dijalog puni u toku rada, kroz set_tile
   ("dcl.kabl.kategorija"  . "Category:  %1")
   ("dcl.nast.kbl.isti"    . "cable %1, only the frame is picked")
   ("dcl.nast.kbl.novi"    . "the cable is picked by clicking a fiber")
   ("dcl.kuc.pre.moduli"   . "   %1 modules, %2 in total")
   ("dcl.kuc.pre.spliter"  . "   splitter 1:%1")
   ("dcl.pal.info"         . "Status: %1     Color code: %2%3")
   ("dcl.pal.info.ormar"   . "     CABLE STARTS AT THE CABINET")
   ("dcl.pal.info.kabl"    . "     ALIGNED WITH A CABLE")

   ;; --- paleta, stavke menija, blok 6 -----------------------------
   ;;
   ;;  Kljucevi stoje u *FQ-MENU*, u polju natpisa.  Prevode se u
   ;;  fq:dclfile, gde su promenljive -- zato imaju svoju proveru, koja
   ;;  cita bas *FQ-MENU*, a ne pozive fq:t.
   ;;
   ;;  ODO je ovde FDH, ZOK je FAT, kao i u porukama iz bloka 4.  Kljuc
   ;;  u xdata se time ne dira.
   ("menu.grupa.kablovi"   . "Cables")
   ("menu.kabl.vazdusni"   . "Aerial...")
   ("menu.kabl.podzemni"   . "Duct...")
   ("menu.kabl.mikro"      . "Micro duct...")
   ("menu.kabl.instalacioni" . "Indoor...")
   ("menu.kabl.rucni"      . "Manual entry...")
   ("menu.kabl.poravnaj"   . "Align with cable")
   ("menu.kabl.cc"         . "Color code...")
   ("menu.kabl.vrsta"      . "Fiber type SM/MM...")
   ("menu.kabl.katalog"    . "Save cable catalogue")

   ("menu.grupa.nastavci"  . "Closures and joining")
   ("menu.nast.n"          . "Closure N...")
   ("menu.nast.nl"         . "Closure NL latent...")
   ("menu.nast.cmd"        . "Closure, command line")
   ("menu.spoj.dva"        . "Join two fibers")
   ("menu.spoj.grupa"      . "Join a group of fibers")
   ("menu.spoj.splajs"     . "Splice onto a fiber")
   ("menu.spoj.odvod"      . "Vertical drop")
   ("menu.spoj.preseci"    . "Cut a fiber")
   ("menu.spoj.prolaz"     . "Through fiber")
   ("menu.spoj.rezerva"    . "Slack 15 m")

   ("menu.grupa.spliteri"  . "Splitters")
   ("menu.spl.2"           . "1:2")
   ("menu.spl.4"           . "1:4")
   ("menu.spl.8"           . "1:8")
   ("menu.spl.16"          . "1:16")
   ("menu.spl.32"          . "1:32")
   ("menu.spl.64"          . "1:64")
   ("menu.spl.ostalo"      . "Other...")
   ("menu.spl.kuciste"     . "Into an FDH or box...")

   ("menu.grupa.odf"       . "ODF modules")
   ("menu.odf.144"         . "ODF 144   (cable 12x12)")
   ("menu.odf.96"          . "ODF 96    (cable 8x12)")
   ("menu.odf.72"          . "ODF 72    (cable 6x12)")
   ("menu.odf.48"          . "ODF 48    (cable 4x12)")
   ("menu.odf.24"          . "ODF 24    (cable 2x12)")
   ("menu.odf.12"          . "ODF 12    (cable 1x12)")
   ("menu.odf.ostalo"      . "Other...")

   ("menu.grupa.odo"       . "FDH cabinets")
   ("menu.odo.24"          . "FDH 24")
   ("menu.odo.48"          . "FDH 48")
   ("menu.odo.96"          . "FDH 96")
   ("menu.odo.ostalo"      . "Other...")

   ("menu.grupa.oltont"    . "OLT and ONT")
   ("menu.olt.8"           . "OLT 8 PON")
   ("menu.olt.16"          . "OLT 16 PON")
   ("menu.ont"             . "ONT subscriber")

   ("menu.grupa.namena"    . "Fiber purpose")
   ("menu.nam.radno"       . "Working")
   ("menu.nam.planirano"   . "Planned")
   ("menu.nam.izgradnja"   . "Under construction")
   ("menu.nam.primljeno"   . "Accepted")
   ("menu.nam.rezervisano" . "Reserved")
   ("menu.nam.osteceno"    . "Damaged")
   ("menu.nam.spliter"     . "Splitter")
   ("menu.nam.rezervno"    . "Spare")
   ("menu.nam.prolazno"    . "Through")
   ("menu.nam.slobodno"    . "Free (back to black)")

   ("menu.grupa.podaci"    . "Data and checks")
   ("menu.pod.info"        . "Element data")
   ("menu.pod.trasa"       . "Fiber route")
   ("menu.pod.bom"         . "Bill of materials to console")
   ("menu.pod.tabela"      . "Bill of materials into drawing")
   ("menu.pod.budzet"      . "Optical budget")
   ("menu.pod.budzettab"   . "Budget into the drawing")
   ("menu.pod.provera"     . "Drawing check")
   ("menu.pod.legenda"     . "Symbol legend")
   ("menu.pod.stil"        . "Apply layer standard")
   ("menu.pod.verzija"     . "Version and environment")
   ("menu.pod.pomoc"       . "User guide")

   ;; --- prefiks i naziv vrste kucista, blok 7 ---------------------
   ;;
   ;;  Cita ih fq:vrpre / fq:vrime, i to samo dok u katalogu stoji
   ;;  isporucena vrednost -- vidi tamo zasto.  Kljuc u xdata ("ODO",
   ;;  "ZOK", "IPAN") se ovim ne dira.
   ;;
   ;;  Razmak na kraju prefiksa je deo prefiksa: oznaka se sklapa kao
   ;;  (strcat pre broj), pa bi bez njega pisalo "FDH1".
   ("vrsta.pre.odo"        . "FDH ")
   ("vrsta.pre.zok"        . "FAT ")
   ("vrsta.ime.odf"        . "ODF module")
   ("vrsta.ime.pp"         . "Patch panel")
   ("vrsta.ime.odo"        . "FDH cabinet")
   ("vrsta.ime.mdu"        . "MDU cabinet")
   ("vrsta.ime.zok"        . "FAT box")

   ;; --- nazivi boja, blok 8 ---------------------------------------
   ;;
   ;;  Cita ih fq:bojnaz, po ACI BROJU.  ACI je vec kod: *FQ-BOJENAZ*
   ;;  preslikava ime u broj na oba jezika, pa obrnut smer daje prikaz
   ;;  bez ijedne nove tabele i bez diranja formata fq-boje.dat.
   ;;
   ;;  Boja kojoj se ACI ne nalazi ovde -- korisnikova -- prolazi kroz,
   ;;  doslovno, isto kao "u podrumu" kod mesta nastavka.
   ("boja.plava"          . "Blue")
   ("boja.narandzasta"    . "Orange")
   ("boja.zelena"         . "Green")
   ("boja.braon"          . "Brown")
   ("boja.siva"           . "Slate")
   ("boja.bela"           . "White")
   ("boja.crvena"         . "Red")
   ("boja.crna"           . "Black")
   ("boja.zuta"           . "Yellow")
   ("boja.ljubicasta"     . "Violet")
   ("boja.roze"           . "Rose")
   ("boja.tirkizna"       . "Aqua")

   ;; --- legenda: tekst koji ide U CRTEZ, blok 8 --------------------
   ;;
   ;;  Odlukom od 20.08.2026 jezik vazi za ono sto se crta OD TOG
   ;;  TRENUTKA; vec nacrtano se ne prepisuje i mesan crtez je prihvacen.
   ;;  Nacrtan TEXT entitet je geometrija i ostaje na jeziku na kom je
   ;;  nastao -- komanda za izbor jezika ne sme tiho da menja crtez.
   ("leg.naslov"          . "SYMBOL LEGEND")
   ("leg.vlakno"          . "Fiber, black line, label colored by the color code")
   ("leg.kabl"            . "Cable, tube with a number, inset from the ends")
   ("leg.nastavak"        . "Closure, designation above the frame")
   ("leg.varenje"         . "Splice between two fibers")
   ("leg.spliter"         . "Splitter 1:K with the loss in dB")
   ("leg.odo"             . "FDH cabinet with taken ports")
   ("leg.odf"             . "ODF module, connectors numbered 1..N")
   ("leg.olt"             . "OLT with PON ports")
   ("leg.ont"             . "ONT with the drop to the subscriber")
   ("leg.rezerva"         . "Cable slack, R = length in m")
   ("leg.namena"          . "FIBER PURPOSE")
   ("leg.colorcode"       . "COLOR CODE:  %1")
  ))

(setq *FQ-STR-SR*
 '(
   ;; --- baner ---
   ("start.sema"          . " -- fq-sema.lsp ucitan.  FIBERQ za paletu, FQPOMOC za uputstvo.")
   ("start.kucista"       . " -- fq-kucista.lsp ucitan.")
   ("start.ribbon"        . " -- fq-ribbon.lsp ucitan.  FQRIBBON / FQRIBBONOFF, paleta je FIBERQ.")
   ("start.kuc.komande"   . "\n  FQKUC dijalog,  FQZOK / FQPP / FQMDU,  -FQZOK za komandnu liniju.")
   ("start.cc.ucitano"    . "\n  Ucitano color code standarda: %1  iz %2")
   ("start.cc.samo"       . "\n  Color code: samo ugradjeni (%1).  Svoj standard pravis dugmetom Color code.")
   ("start.cc.aktivan"    . "\n  Aktivan color code: %1")
   ("start.kbl.ucitan"    . "\n  Katalog kablova ucitan iz %1")
   ("start.kbl.dopisano"  . "\n  Dopisano tipova kabla iz isporucenog kataloga: %1.  FQKABLSAVE ih trajno upisuje.")
   ("start.kat.ucitan"    . "\n  Katalog kucista ucitan iz %1")
   ("start.kat.dopisano"  . "\n  Dopisano vrsta iz isporucenog kataloga: %1.  FQKATSAVE ih trajno upisuje.")
   ("start.orijentacija"  . "\n  Orijentacija se bira na paleti i u dijalogu kabla.\n")
   ;; --- FQJEZIK ---
   ("jezik.postavljen"    . "\nJezik interfejsa: %1.  Vazi za ono sto se od sada crta.")
   ("jezik.isti"          . "\nJezik interfejsa je vec %1.")
   ("jezik.naziv.EN"      . "engleski")
   ("jezik.naziv.SR"      . "srpski")
   ;; --- promptovi trajnih nabrajanja (blok 3) ---
   ("opste.pitaj.status"   . "\nStatus [%1] <%2>: ")
   ("vlakno.pitaj.vrsta"   . "\nVrsta vlakna [%1] <%2>: ")
   ("vlakno.pitaj.namena"  . "\nNamena [%1] <%2>: ")
   ("kabl.pitaj.kategorija". "\nKategorija [%1] <%2>: ")
   ("odo.pitaj.montaza"    . "\nPostavljanje [%1] <%2>: ")
   ("nast.pitaj.tip"       . "\nTip [%1] <%2>: ")
   ;; --- zajednicki recnik (blok 4.1) ---
   ("opste.otkazano"           . "\nOtkazano.")
   ("opste.nista"              . "\nNista nije izabrano.")
   ("opste.bez.oznake"         . "(bez oznake)")
   ("opste.pregled.ne"         . "\n  Pregled nije moguc, klasican unos tacke.")
   ("opste.pregled.zasto"      . "\n  Razlog: %1")
   ("opste.nije.vlakno"        . "\nTo nije vlakno.")
   ("opste.nije.element"       . "\nTo nije FiberQ element.")
   ("opste.nema.elemenata"     . "\nU crtezu nema oznacenih FIBERQ elemenata.")
   ("opste.dcl.ne"             . "\nNe mogu da napisem DCL fajl u temp folder.")
   ("opste.ram.ugao"           . "\nNe mogu da procitam ugao rama.")
   ("opste.ram.temena"         . "\nTaj ram nema cetiri temena.")
   ("opste.poravnanje.potroseno" . "\nPoravnanje iskorisceno i ponisteno.")
   ("opste.poravnanje.ponisti" . "\nAko to ne zelis, dugme Poravnaj sa kablom ponistava.")
   ("spoj.presk.nijevlakno"    . "\n  preskoceno, nije vlakno")
   ("spoj.presk.isto"          . "\n  preskoceno, isto vlakno izabrano dva puta")
   ("spoj.red.nijevlakno"      . "  nije vlakno")
   ("spoj.red.otkazano"        . "  otkazano")
   ("kuc.ram.fqdodaj"          . "\n  Ram mozes rasiriti komandom FQDODAJ.")
   ("kuc.ogledalo"             . "\n  Ogledalno: snop dolazi sa druge strane, pa telo ide desno od kolone konektora.")
   ("kuc.sirenje.otkazano"     . "\n  Sirenje kucista otkazano.  FQDODAJ ga radi naknadno.")
   ("kabl.deo.bezduz"          . "\n  Taj deo nema duzinu.")
   ("kabl.nema.vlakana"        . "\nNe mogu da nadjem vlakna tog kabla.")
   ("kabl.polozaj.ormar"       . "\nPolozaj preuzet sa ormara, kabl krece iz njega.")
   ;; --- traka (blok 4.1) ---
   ("opste.da"                 . "da")
   ("opste.ne"                 . "ne")
   ("opste.orijentacija.h"     . "horizontalno")
   ("opste.orijentacija.v"     . "vertikalno")
   ("traka.greska"             . "\nFiberQ, greska: %1")
   ("traka.stanje"             . "\nFiberQ  status: %1   orijentacija: %2   pregled uz mis: %3   kabl siri kuciste: %4   hvatanje: %5   color code: %6")
   ("traka.vec.ucitana"        . "\nFiberQ traka je vec ucitana.")
   ("traka.nije.ucitana"       . "\nFiberQ traka nije ucitana.")
   ("traka.nema.cuix"          . "\nNe nalazim FiberQ.cuix.")
   ("traka.nema.cuix.alert"    . "FiberQ\n\nNe nalazim FiberQ.cuix.\n\nDodaj folder u kome je FiberQ.cuix u\nOptions / Files / Support File Search Path,\npa pokreni FQRIBBON ponovo.")
   ("traka.cuix.greska"        . "\nNe mogu da ucitam FiberQ.cuix: %1")
   ("traka.ucitana"            . "\nFiberQ traka ucitana iz %1")
   ("traka.uklanjanje.greska"  . "\nNe mogu da uklonim traku: %1")
   ("traka.uklonjena"          . "\nFiberQ traka uklonjena.")
   ;; --- specifikacija, fq:tallytxt (blok 4.2) ---
   ;;
   ;;  "prolazna" i "presecena" su ZENSKI ROD, jer stoje uz "vlakna".
   ;;  Tabela *FQ-KODOVI* nosi "prolazno" / "preseceno" (srednji rod, uz
   ;;  "vlakno"), pa se ovaj spoj ne moze izvesti iz nje -- rod se iz
   ;;  koda ne cita.  Engleski razliku nema, ali su kljucevi ipak dva,
   ;;  da srpski oblik ima gde da stoji.
   ("bom.vlakno"           . "Vlakna, %1%2%3%4")
   ("bom.vlakno.prolazna"  . ", prolazna")
   ("bom.vlakno.presecena" . ", presecena")
   ("bom.varenje"          . "Varenja")
   ("bom.varenje.u"        . "Varenja u %1")
   ("bom.nastavak"         . "Nastavci %1%2")
   ("bom.spliter"          . "Spliteri %1")
   ("bom.odf"              . "ODF%1, zauzeto %2 od %3")
   ("bom.pp"               . "Patch panel%1, zauzeto %2 od %3")
   ("bom.odo"              . "ODO %1%2, zauzeto %3")
   ("bom.mdu"              . "MDU %1%2, zauzeto %3")
   ("bom.zok"              . "ZOK%1 %2x%3%4%5")
   ("bom.zok.spliter"      . "spliter %1")
   ("bom.olt"              . "OLT %1 PON")
   ("bom.ont"              . "ONT")
   ("bom.pon"              . "PON portovi")
   ("bom.privod"           . "Privodi")
   ("bom.rezerva"          . "Rezerva %1 m")
   ("bom.naslov"           . "\n--- SPECIFIKACIJA ELEMENATA ---")
   ("bom.upisano"          . "\nUpisano stavki: %1")
   ;; --- FQPROVERA (blok 4.2) ---
   ("prov.naslov"          . "\n--- PROVERA CRTEZA ---")
   ("prov.zaglavlje"       . "\n  vlakana %1, nastavaka %2, varenja %3")
   ("prov.stavka"          . "\n        %1")
   ("prov.jos"             . "\n        ... i jos %1")
   ("prov.1.ima"           . "\n  [1] dupli id vlakna: %1")
   ("prov.1.nema"          . "\n  [1] dupli id vlakna: nema")
   ("prov.1.savet"         . "\n        verovatno je neko kopirao vlakno, podaci se kopiraju sa njim")
   ("prov.2.ima"           . "\n  [2] kabl %1, dupli redni brojevi: ")
   ("prov.2.nema"          . "\n  [2] redni brojevi u kablovima: bez duplikata")
   ("prov.2.kabl"          . "\n      kabl %1: %2 vlakana nosi tu oznaku%3%4")
   ("prov.2.presecenih"    . ", od toga presecenih %1")
   ("prov.2.spojeno"       . ", %1 spojeno u druge kablove")
   ("prov.3.ima"           . "\n  [3] port zauzet vise puta: %1")
   ("prov.3.nema"          . "\n  [3] portovi ODF i ODO: nema dvostruko zauzetih")
   ("prov.4.ima"           . "\n  [4] nastavak bez varenja: %1")
   ("prov.4.nema"          . "\n  [4] nastavci: svi imaju bar jedno varenje")
   ("prov.4.savet"         . "\n        ako kroz njih vlakna samo prolaze, to su latentni nastavci (NL)")
   ("prov.4.latentni"      . "\n      latentnih nastavaka preskoceno: %1   (u njima varenja i ne treba da bude)")
   ("prov.5.ima"           . "\n  [5] varenje bez vlakna: %1 / %2%3")
   ("prov.5.mesto"         . "  u %1")
   ("prov.5.nema"          . "\n  [5] varenja: sva pokazuju na postojeca vlakna")
   ("prov.6"               . "\n  [6] radnih vlakana bez zavrsetka: %1%2")
   ("prov.6.napomena"      . "   (nisu greska ako je trasa u izradi)")
   ("prov.ukupno"          . "\n  UKUPNO nalaza: %1")
   ("prov.cist"            . "\n  Crtez je cist.")
   ("info.nema"            . "\nNema FIBERQ podataka na ovom entitetu.")

   ;;  Natpisi polja za c:FQINFO.  Kljuceve predaje *FQ-POLJA* iz
   ;;  fq-sema.lsp, dakle kao PROMENLJIVU -- zato ih ne cuva odeljak
   ;;  "kljuc mora biti doslovna niska" nego odeljak koji gleda samu
   ;;  tabelu.  Svaki nosi tacno jedan umetak i pocinje prelomom reda;
   ;;  poravnanje kolone je posao prevodioca, isto kao kod tras.*.
   ("info.zaglavlje"      . "\n--- PODACI O ELEMENTU:  %1 ---")
   ("info.zapis"          . "\n\n  zapis kakav stoji u crtezu (kodovi, ne prevode se):")
   ("info.p.id"           . "\n  id            %1")
   ("info.p.kabl"         . "\n  kabl          %1")
   ("info.p.cevcica"      . "\n  cevcica       %1")
   ("info.p.ucevcici"     . "\n  u cevcici     %1")
   ("info.p.rbr"          . "\n  redni broj    %1")
   ("info.p.boja"         . "\n  boja          %1")
   ("info.p.status"       . "\n  status        %1")
   ("info.p.zavrseci"     . "\n  zavrseci      %1")
   ("info.p.prolaznost"   . "\n  prolaznost    %1")
   ("info.p.namena"       . "\n  namena        %1")
   ("info.p.natpis"       . "\n  natpis        %1")
   ("info.p.kategorija"   . "\n  kategorija    %1")
   ("info.p.ugao"         . "\n  ugao          %1")
   ("info.p.colorcode"    . "\n  color code    %1")
   ("info.p.lanac"        . "\n  lanac         %1")
   ("info.p.opis"         . "\n  opis          %1")
   ("info.p.vrsta"        . "\n  vrsta vlakna  %1")
   ("info.p.duzina"       . "\n  duzine        %1")
   ("info.p.oznaka"       . "\n  oznaka        %1")
   ("info.p.model"        . "\n  model         %1")
   ("info.p.kapacitet"    . "\n  kapacitet     %1")
   ("info.p.zauzeto"      . "\n  zauzeto       %1")
   ("info.p.konektor"     . "\n  konektor      %1")
   ("info.p.letva"        . "\n  letva, modul  %1")
   ("info.p.montaza"      . "\n  montaza       %1")
   ("info.p.adresa"       . "\n  adresa        %1")
   ("info.p.spliter"      . "\n  spliter       %1")
   ("info.p.tip"          . "\n  tip           %1")
   ("info.p.mesto"        . "\n  mesto         %1")
   ("info.p.broj"         . "\n  broj          %1")
   ("info.p.odnos"        . "\n  odnos         %1")
   ("info.p.gubitak"      . "\n  gubitak dB    %1")
   ("info.p.izlaz"        . "\n  izlaz         %1")
   ("info.p.port"         . "\n  port          %1")
   ("info.p.portovi"      . "\n  PON portova   %1")
   ("info.p.korisnik"     . "\n  korisnik      %1")
   ("info.p.olt"          . "\n  OLT           %1")
   ("info.p.ont"          . "\n  ONT           %1")
   ("info.p.duzinam"      . "\n  duzina m      %1")
   ("info.p.vlaknoa"      . "\n  vlakno A      %1")
   ("info.p.vlaknob"      . "\n  vlakno B      %1")
   ("info.p.nacin"        . "\n  nacin         %1")
   ("info.p.nastavak"     . "\n  nastavak      %1")
   ("bom.pitaj.tacka"      . "\nTacka umetanja tabele (gore levo): ")
   ("bom.tabela.naslov"    . "SPECIFIKACIJA ELEMENATA")
   ;; --- FQBUDZET (blok 4.2) ---
   ("budz.tok.vlakno"      . "Vlakno")
   ("budz.tok.rucno"       . "Rucno")
   ("budz.pitaj.izvor"     . "\nOdakle podaci [%1/%2] <%3>: ")
   ("budz.pitaj.vlakno"    . "\nIzaberi vlakno trase: ")
   ("budz.pitaj.km"        . "\nDuzina trase OLT-ONT u km <2.0>: ")
   ("budz.pitaj.varenja"   . "\nBroj varenja <8>: ")
   ("budz.pitaj.konektori" . "\nBroj konektorskih parova <4>: ")
   ("budz.pitaj.spl1"      . "\nPrvi stepen splitera K (0 ako nema) <4>: ")
   ("budz.pitaj.spl2"      . "\nDrugi stepen splitera K (0 ako nema) <8>: ")
   ("budz.pitaj.talasna"   . "\nTalasna duzina [%1] <%2>: ")
   ("budz.izcrteza"        . "\nIz crteza: %1, varenja %2, konektorskih parova %3%4")
   ("budz.bez.zavrsetka"   . "\n  Vlakno nema upisan nijedan zavrsetak, proveri ODF i ODO.")
   ("budz.bez.vrste"       . "\n  Vlakno nema upisanu vrstu -- crtez je stariji od 1.0.0.\n  Postavlja je komanda FQVRSTA; do tada je pitam ovde.")
   ("budz.rucno"           . "\nNije izabrano vlakno, prelazim na rucni unos.")
   ("budz.naslov"          . "\n--- OPTICKI BUDZET, %1, %2 nm ---")
   ("budz.tabela.naslov"   . "OPTICKI BUDZET, %1, %2 nm")
   ("budz.upisano"         . "\nBudzet upisan u crtez.")
   ("budz.red.vlakno"      . "\n  vlakno     %1 km x %2 dB/km = %3 dB")
   ("budz.red.varenja"     . "\n  varenja    %1 x %2 = %3 dB")
   ("budz.red.konektori"   . "\n  konektori  %1 x %2 = %3 dB")
   ("budz.red.spliter"     . "\n  spliter 1:%1  = %2 dB")
   ("budz.red.rezerva"     . "\n  rezerva    %1 dB")
   ("budz.red.ukupno"      . "\n  UKUPNO     %1 dB")
   ("budz.klasa"           . "\n  klasa %1 (%2 dB): %3")
   ("budz.prolazi"         . "prolazi")
   ("budz.neprolazi"       . "NE prolazi")
   ;; --- FQTRASA (blok 4.2) ---
   ("tras.naslov"          . "\n--- TRASA VLAKNA ---")
   ("tras.kabl"            . "\n  kabl        %1%2")
   ("tras.vlakno"          . "\n  vlakno      %1, cevcica %2, boja %3, redni broj %4")
   ("tras.namena"          . "\n  namena      %1,  status %2%3")
   ("tras.deonice"         . "\n  deonice     ")
   ("tras.varenja"         . "\n  varenja     %1")
   ("tras.unastavcima"     . "   u nastavcima: ")
   ("tras.zavrseci"        . "\n  zavrseci    ")
   ("tras.zavrseci.nema"   . "\n  zavrseci    nema, vlakno nigde nije zavrseno")
   ("tras.konektori"       . "\n  konektori   %1 konektorskih parova")
   ("tras.oznaka"          . "\n  Vlakno je oznaceno u crtezu.  Oznaka se skida sledecim\n  FQTRASA -- i kad se na pitanju za vlakno pritisne Esc.\n  FQBUDZET moze da preuzme ove brojeve, opcija Vlakno.")
   ;; --- kabl, lomovi, namena, poravnanje (blok 4.3) ---
   ("opste.tok.da"         . "Da")
   ("opste.tok.ne"         . "Ne")
   ("opste.vodoravno"      . "vodoravno")
   ("opste.uspravno"       . "uspravno")
   ("opste.drag.hint"      . "%1  [klik postavlja, O za osnap]")
   ("opste.osnap.tacka"    . "\n  Osnap: pokazi tacku: ")
   ("opste.snap.ramova"    . "\n  Hvatanje na prvi konektor, ramova u crtezu: %1.")
   ("opste.pregled.ne.vise" . "\n  Pregled nije moguc, klasican unos tacaka.")
   ("kabl.velik"           . "\nKabl %1x%2 ima %3 vlakana, crtanje moze da potraje. Nastaviti? [%4/%5] <%4>: ")
   ("kabl.uhvacen"         . "\n  Uhvacen konektor %1, ugao %2.")
   ("kabl.pitaj.cevcica"   . "\nBroj cevcica <2>: ")
   ("kabl.pitaj.povlakn"   . "\nBroj vlakana po cevcici <6>: ")
   ("kabl.pitaj.tip"       . "\nTip kabla, prazno za bez tipa: ")
   ("kabl.pitaj.oznaka"    . "\nOznaka kabla <auto>: ")
   ("kabl.povuci.duzinu"   . "\nPovuci duzinu kabla   [klik prihvata, Enter zadrzava %1]")
   ("kabl.povlacenje.ne"   . "\n  Povlacenje nije moguce, ostaje upisana duzina.")
   ("kabl.kratak.natpis"   . "\nKabl je kratak za natpis na oba kraja, ostaje samo levi.")
   ("kabl.nacrtan"         . "\nKabl %1 = %2 vlakana, %3, ugao %4%5")
   ("kabl.redovi.mreza"    . ", redovi po mrezi referentnog kabla")
   ("kabl.polozaj.ormar2"  . "\nPolozaj preuzet sa ormara.")
   ("kabl.nepoznata.kat"   . "\nNepoznata kategorija: %1")
   ("kabl.tip.dopisan"     . "\nNov tip kabla dopisan u katalog: %1.  FQKABLSAVE ga trajno cuva.")
   ("kabl.dijalog.ne"      . "\nNe mogu da otvorim dijalog kabla.")
   ("odo.raspored"         . "\nRaspored kabla koji ce uci u ormar.")
   ("odo.pitaj.povlakn"    . "\n  Vlakana po cevcici <12>: ")
   ("odo.pitaj.cevcica"    . "\n  Broj cevcica <%1>: ")
   ("lom.nema.duzine"      . "\nPutanja kabla nema nijedan deo sa duzinom.")
   ("lom.deo.kratak"       . "\nDeo broj %1 je prekratak za snop od %2 vlakana: na njemu bi se vlakno %3 preokrenulo.\nProduzi taj deo putanje ili izostavi jedan lom.\nNista nije nacrtano.")
   ("lom.prvi.kratak"      . "\nPrvi deo je kratak za natpise (%1, treba %2), na tom kraju ih nema.")
   ("lom.zadnji.kratak"    . "\nPoslednji deo je kratak za natpise (%1, treba %2), ostaje samo pocetni kraj.")
   ("lom.nacrtan"          . "\nKabl %1 = %2 vlakana, %3%4, ukupno %5, kraj pod uglom %6%7.")
   ("lom.povuci"           . "\nPovuci kabl: klik lomi pod pravim uglom, Enter zavrsava, U ponistava lom, O za osnap.")
   ("lom.deo.bezduz"       . "\n  Taj deo nema duzinu, klikni dalje od poslednjeg loma.")
   ("lom.nema.loma"        . "\n  Nema loma za ponistavanje.")
   ("lom.osnap.tacka"      . "\n  Osnap: pokazi tacku loma: ")
   ("lom.tacke"            . "\nTacke loma, Enter zavrsava kabl.")
   ("lom.pitaj.lom"        . "\n  Lom ili kraj (%1), Enter zavrsava: ")
   ("lom.duzina.izputanje" . "\nKabl sa lomovima.  Duzina se ne unosi, dobija se iz putanje.")
   ("por.treba.kucista"    . "\nZa poravnanje po ramu treba i fq-kucista.lsp.")
   ("por.ponisteno"        . "\nPoravnanje ponisteno.")
   ("por.sa.rama"          . "\nPoravnanje uzeto sa rama %1, ugao %2.")
   ("por.prvi.konektor"    . "\nSledeci kabl krece tacno iz prvog konektora, bez pokazivanja tacke.")
   ("por.prvi.red"         . "\nSledeci kabl lezi u prvom redu rama, polozaj duz kabla se pokazuje.")
   ("por.ogledalo"         . "\n%1 je ogledalno: portovi su okrenuti od strane sa koje kabl ide, pa iz njega kabl ne moze da krene. Umesto toga zakaci KRAJ kabla na njegove konektore.")
   ("por.pitaj"            . "\nPoravnati [%1/%2] <%3>: ")
   ("por.tok.mreza"        . "Mreza")
   ("por.tok.pocetak"      . "Pocetak")
   ("por.redovi.ne"        . "\nNe mogu da procitam redove tog kabla.")
   ("por.sa.vlakna"        . "\nPoravnanje uzeto sa vlakna %1 (kabl %2, redni broj %3), ugao %4.")
   ("por.mreza"            . "\nMreza: na raspolaganju %1 redova, novi kabl lezi red u red.")
   ("por.samo.prvi"        . "\nPreuzima se samo prvi red, dalje prirodni raster.")
   ("nam.nepoznata"        . "\nNepoznata namena: %1")
   ("nam.izaberi"          . "\nIzaberi vlakna, namena: %1")
   ("nam.promenjeno"       . "\nPromenjeno vlakana: %1, namena %2.")
   ("vrs.izaberi"          . "\nIzaberi vlakna, vrsta: %1 - %2")
   ("vrs.promenjeno"       . "\nPromenjeno vlakana: %1, vrsta %2.")
   ("duz.pitaj.vlakno"     . "\nVlakno kabla cija se duzina unosi: ")
   ("duz.prolazi"          . "\nVlakno prolazi kroz: %1")
   ("duz.pitaj.duzina"     . "\nStvarna duzina kabla %1 u metrima <%2>: ")
   ("duz.nepoznata"        . "nepoznata")
   ("duz.negativna"        . "\n%1: duzina ne moze biti negativna, preskoceno.")
   ("duz.upisano"          . "\n%1 = %2 m, upisano na %3 vlakana.")
   ("duz.nista"            . "\nNista nije upisano.")
   ("kabl.pitaj.tacka"     . "\nTacka umetanja: ")
   ("kabl.pitaj.polozaj"   . "\nPokazi polozaj, red se preuzima: ")
   ("kabl.pitaj.tacka.tip" . "\n%1 - tacka umetanja: ")
   ("kabl.pitaj.polozaj.tip" . "\n%1 - pokazi polozaj, red se preuzima: ")
   ("lom.broj.1"           . "%1 lom")
   ("lom.broj.2"           . "%1 loma")
   ("lom.broj.5"           . "%1 lomova")
   ;; --- ODO, ODF, nastavak, spliter, OLT/ONT (blok 4.4) ---
   ("opste.tok.kabl"       . "Kabl")
   ("opste.tok.samostalno" . "Samostalno")
   ("opste.pitaj.kaci"     . "\n%1 se kaci [%2/%3] <%4>: ")
   ("odo.nacrtan"          . "\n%1 (%2)%3%4, %5%6")
   ("odo.portovi"          . ", iskorisceno %1 portova (%2 do %3)")
   ("odo.portovi.nema"     . ", nijedan port nije zauzet")
   ("odo.visi"             . ", u ormaru visi jos %1 vlakana")
   ("odo.pitaj.oznaka"     . "\nOznaka ormara <auto>: ")
   ("odo.pitaj.adresa"     . "\nAdresa i broj: ")
   ("odo.pitaj.kapacitet"  . "\nKapacitet ormara <48>: ")
   ("odo.pitaj.model"      . "\nModel ormara <bez>: ")
   ("odo.pitaj.portovi"    . "\nBroj iskoriscenih portova <%1>: ")
   ("odo.pitaj.tacka"      . "\nTacka PRVOG porta ormara: ")
   ("odo.poravnanje"       . "\nPoravnanje postavljeno na ormar %1.")
   ("odo.sledeci"          . "\nSledeci kabl krece iz prvog porta, raspored %1x%2, bez pokazivanja tacke.")
   ("odf.nacrtan"          . "\nODF %1  %2%3, iskorisceno %4 od %5 konektora, %6")
   ("odf.pitaj.kapacitet"  . "\nKapacitet ODF-a <%1>: ")
   ("odf.pitaj.objekat"    . "\nNaziv objekta, ide posle OR <NAZIV>: ")
   ("odf.pitaj.konektor"   . "\nTip konektora <%1>: ")
   ("odf.pitaj.model"      . "\nTip i model ODF-a <ODF 19\" %1x%2>: ")
   ("odf.pitaj.letva"      . "\nLetva i modul, opciono: ")
   ("odf.pitaj.konektori"  . "\nBroj iskoriscenih konektora <%1>: ")
   ("odf.pitaj.tacka"      . "\nTacka PRVOG konektora ODF-a: ")
   ("odf.poravnanje"       . "\nPoravnanje postavljeno na ODF %1.")
   ("odf.sledeci"          . "\nSledeci kabl krece iz prvog konektora, raspored %1x%2, bez pokazivanja tacke.")
   ("nast.nacrtan"         . "\nNastavak %1 (%2), sirina %3%4, %5")
   ("nast.info"            . "\nNastavak: %1   ram %2 .. %3, sredina %4%5")
   ("nast.info.izvan"      . ", kraj vlakna %1 izvan rama")
   ("nast.paznja.red"      . "\n  PAZNJA: red vlakna je %1 izvan visine rama. Proveri da li je to zaista taj nastavak.")
   ("nast.nema.pod.uglom"  . "\nU crtezu nema nijednog nastavka pod tim uglom.")
   ("nast.povuci.ivicu"    . "\nDesna ivica nastavka   [klik prihvata, Enter zadrzava sirinu %1]")
   ("nast.pitaj.ivica"     . "\nDesna ivica nastavka: ")
   ("nast.pitaj.leva"      . "\nLeva ivica nastavka: ")
   ("nast.isti.kabl"       . "\nKabl %1, isti kao za prethodni nastavak.")
   ("nast.kabl.uvod"       . "\n  Kabl krece sa nastavka %1; pomeren za %2 duz kabla.")
   ("nast.siri"            . "\n  Nastavak %1 prima nov kabl, %2 vlakana%3.")
   ("nast.siri.ram"        . "; ram je prosiren")
   ("nast.nije.prosireno"  . "\n  Nastavak na kraju kabla nije prosiren: ")
   ("nast.natpisi.unutra"  . "\n  PAZNJA: nastavak %1 ima %2 oznaka cevcica unutar rama. Povuci ivicu rama blize kraju kabla, ili pomeri kabl.")
   ("nast.prelom"          . "\nNastavak prelazi preko preloma kabla. Visina rama je uzeta na njegovoj levoj ivici.")
   ("nast.dijalog.ne"      . "\nNe mogu da otvorim dijalog nastavka.")
   ("nast.pitaj.oznaka"    . "\nOznaka nastavka <auto>: ")
   ("nast.pitaj.mesto"     . "\nGde se nalazi, okno ili stub <%1>: ")
   ("nast.pitaj.broj"      . "\nBroj okna ili stuba%1: ")
   ("spl.nacrtan"          . "\nSpliter %1 1:%2, gubitak %3 dB, %4")
   ("spl.u.kucistu"        . "\n  Zavrsava na koloni konektora kucista, ali je ZASEBAN element: samo prvih nekoliko izlaza padne na zatecene portove, ostali ostaju bez konektora, a ram se ne siri.\n  Spliter UNUTAR kucista crta FQSPLKUC - svaki izlaz dobije svoj port i ram poraste da ih primi.")
   ("spl.pitaj.k"          . "\nSpliter 1:K, unesi K <32>: ")
   ("spl.pitaj.oznaka"     . "\nOznaka <auto>: ")
   ("spl.pitaj.kraj"       . "\nKraj prvog izlaza, na konektor: ")
   ("spl.pitaj.kraj.oz"    . "\nSpliter %1 1:%2 - kraj prvog izlaza, na konektor: ")
   ("spl.hvat.izlaz"       . "\n  hvataljka: kraj prvog izlaza; I je prebacuje na ulaz")
   ("spl.hvat.ulaz"        . "\n  hvataljka: ulaz splitera; I je vraca na prvi izlaz")
   ("spl.pitaj.ormar"      . "\nOrmar ili kutija u koju ide spliter: ")
   ("spl.treba.kucista"    . "\nSpliter u kuciste trazi fq-kucista.lsp, koji nije ucitan.\nSamostalan spliter i dalje radi.")
   ("olt.nacrtan"          . "\nOLT %1: %2 PON portova, %3")
   ("olt.pitaj.oznaka"     . "\nOznaka OLT <auto>: ")
   ("olt.pitaj.portovi"    . "\nBroj PON portova <16>: ")
   ("olt.pitaj.tacka"      . "\n%1  %2 PON - kraj prvog PON porta: ")
   ("ont.nacrtan"          . "\nONT %1 %2, %3")
   ("ont.pitaj.oznaka"     . "\nOznaka ONT <ONT>: ")
   ("ont.pitaj.korisnik"   . "\nKorisnik / stan: ")
   ("ont.pitaj.tacka"      . "\nONT - kraj privoda, na konektor: ")
   ("rez.nacrtan"          . "\nRezerva %1 m, %2")
   ("rez.zaokruzeno"       . "  (upisano %1, zaokruzeno na ceo metar)")
   ("rez.pitaj.tacka"      . "\nRezerva %1 m - tacka: ")
   ("odo.naziv"            . "ODO")
   ("odf.naziv"            . "ODF")
   ("odo.pitaj.vlakno"     . "\nVlakno kabla, klikni blizu kraja gde stoji ormar: ")
   ("odf.pitaj.vlakno"     . "\nVlakno kabla, klikni blizu kraja gde stoji ODF: ")
   ;; --- spajanje, splajs, odvod, presecanje (blok 4.5) ---
   ("opste.nagore"         . "nagore")
   ("opste.nanize"         . "nanize")
   ("spoj.gotovo"          . "\nVlakna spojena.")
   ("spoj.paznja.stepenik" . "\n  PAZNJA: krajevi nisu u istom redu, na spoju ostaje stepenik.")
   ("spoj.gusto"           . "\n  Za %1 spoj(a) nema mesta bez preklapanja, pa dele deo reda ili kolone.  Dva vlakna koja ZAMENE redove se u pravouglom crtezu ne mogu razdvojiti; ostalima pomaze siri ram nastavka.")
   ("spl2.nema.putanje"    . "  vlakno nema putanju")
   ("spl2.nema.elementa"   . "\n  Na tom mestu nema nastavka ni kucista.")
   ("spl2.postavljen"      . "  %1, splajs%2")
   ("spl2.umestu"          . " u %1")
   ("spl2.misem"           . "\n  mesto splajsa se od sada pokazuje misem")
   ("spl2.sredina"         . "\n  splajs od sada ide na sredinu elementa")
   ("spl2.ukupno"          . "\nPostavljeno splajseva: %1")
   ("grp.kabl.a"           . "\nA: %1  %2 vlakana, krece od %3")
   ("grp.kabl.b"           . "\nB: %1  %2 vlakana, krece od %3")
   ("grp.pitaj.koliko"     . "\nKoliko vlakana spojiti <12>: ")
   ("grp.pitaj.korak"      . "\nKorak, 1 spaja redom, 2 preskace svako drugo <1>: ")
   ("grp.uspravni"         . "\nParova sa uspravnim krajem: %1, spoj ide pravim uglom do kolone izvoda.")
   ("grp.paznja.redovi"    . "\nPAZNJA: %1 od %2 parova ne lezi u istom redu.")
   ("grp.raspored"         . "\nDva kabla nemaju isti raspored cevcica, pa ce ta vlakna imati stepenik.")
   ("grp.savet1"           . "\nAko to ne zelis, prekini, obrisi kabl B i postavi ga ponovo preko")
   ("grp.savet2"           . "\ndugmeta Poravnaj sa kablom, opcija Mreza.")
   ("grp.otkazano"         . "\nOtkazano, nije spojeno nista.")
   ("grp.nema.para"        . "\n  nema para za vlakno %1")
   ("grp.spojeno"          . "\nSpojeno parova: %1, korak %2%3%4")
   ("grp.unastavku"        . ", nastavak %1")
   ("grp.stepenik"         . ", sa stepenikom: %1")
   ("odv.pitaj.koliko"     . "\nKoliko vlakana ide u odvod <6>: ")
   ("odv.smer"             . "\nOdvod %1, lom se racuna, stepen %2, od koordinate %3")
   ("odv.nema.vlakna"      . "\n  nema vlakna %1")
   ("odv.presk.uspravno"   . "\n  vlakno %1 preskoceno, kraj nije vodoravan")
   ("odv.ukupno"           . "\nOdvedeno vlakana: %1.")
   ("odv.dalje"            . "\nSada na tom kraju idu nastavak i spajanje.")
   ("prs.element"          . "\n  %1 %2, ram %3 .. %4")
   ("prs.paznja.red"       . "\n  PAZNJA: red vlakna je %1 izvan visine rama. Proveri da li je to zaista taj element.")
   ("prs.nema.elementa"    . "\nU crtezu nema nastavka ni kucista na tom mestu.")
   ("prs.ne.mogu"          . "\n  ne mogu da presecem %1 u %2")
   ("prs.tom.mestu"        . "tom mestu")
   ("prs.jedno"            . "\n  %1%2%3")
   ("prs.preseceno"        . " preseceno")
   ("prs.uvedeno"          . " uvedeno i prekinuto")
   ("prs.umestu"           . " u %1")
   ("prs.pitaj.ugao2"      . "\nDrugi ugao, prevuci preko vlakana: ")
   ("prs.uprozoru"         . "\nU prozoru je vlakana: %1")
   ("prs.prazan.prozor"    . "\n  u prozoru nema vlakana")
   ("prs.ukupno"           . "\nPresecenih vlakana: %1%2%3")
   ("prs.oba.kraka"        . ", od toga sa oba kraka: %1")
   ("prs.obrisano.var"     . ", obrisano varenja u zevu: %1")
   ("pro.skinuto"          . "  %1, skinuto tacaka: %2")
   ("pro.upisano"          . "  %1 upisano kao prolazno")
   ("pro.spojeno"          . "  spojeno u pravo vlakno")
   ("pro.ukupno"           . "\nProlaznih vlakana: %1%2%3")
   ("pro.ukupno.tacke"     . ", skinuto tacaka: %1")
   ("pro.ukupno.krakovi"   . ", spojeno krakova: %1")
   ("grp.pitaj.svejedno"   . "\nSvejedno spojiti? [%1/%2] <%3>: ")
   ;; --- katalog, color code, lejeri, paleta, FQINFO (blok 4.6) ---
   ("opste.lwdisplay"      . "\nUkljucen prikaz debljina linija (LWDISPLAY).")
   ("opste.ucs.1"          . "\nFiberQ crta samo u svetskom koordinatnom sistemu (WCS).")
   ("opste.ucs.2"          . "\n  Otkucaj  UCS  pa  W  pa Enter, i ponovi komandu.")
   ("opste.ucs.3"          . "\n  Pregled, specifikacija i budzet rade i ovako.")
   ("opste.nije.broj"      . "\n  \"%1\" nije broj.  Decimale idu sa zarezom ili tackom.")
   ("opste.nije.vlakno.kabla" . "\nIzabrani element nije vlakno iz kabla.")
   ("kbl.sacuvan"          . "\nKatalog kablova sacuvan u %1")
   ("kbl.ne.sacuvan"       . "\nNe mogu da sacuvam katalog kablova u %1")
   ("cc.pitaj.boja"        . "\nNaziv nove boje: ")
   ("cc.boja.dodata"       . "\nDodata boja %1, ACI %2.")
   ("cc.editor.ne"         . "\nNe mogu da otvorim editor standarda.")
   ("cc.aktivan"           . "\nAktivan color code: %1")
   ("cc.primenjen"         . "\nPrimenjen standard na %1 lejera.")
   ("kabl.izabran"         . "\nKabl %1  %2, %3 vlakana, ugao %4 stepeni, kraj na %5.")
   ("leg.upisana"          . "\nLegenda upisana.")
   ("pal.ne.mogu"          . "\nNe mogu da otvorim paletu.")
   ("pal.greska"           . "\nGreska u komandi %1: %2")
   ("pal.greska.alert"     . "FiberQ, greska u komandi %1:\n\n%2")
   ("info.sema"            . "\n  fq-sema.lsp     ucitan")
   ("info.ucitan"          . "ucitan")
   ("info.ucitana"         . "ucitana")
   ("info.nije.ucitana"    . "nije ucitana")
   ("info.kucista"         . "\n  fq-kucista.lsp  %1")
   ("info.kucista.nema"    . "NIJE ucitan -- nema ZOK, patch panel ni MDU")
   ("info.traka"           . "\n  traka           %1")
   ("info.cad"             . "\n  CAD             %1   %2")
   ("info.cc"              . "\n  color code      %1")
   ("info.katalog"         . "\n  katalog         %1")
   ("info.katalog.podr"    . "\n  katalog         podrazumevan, bez modela")
   ("info.kbl"             . "\n  katalog kablova %1")
   ("info.kbl.podr"        . "\n  katalog kablova podrazumevan")
   ("info.ccfajl"          . "\n  color code fajl %1")
   ("info.ccfajl.nema"     . "\n  color code fajl nema, samo ugradjeni standardi")
   ("info.pisu"            . "\n  boje se pisu u %1")
   ("info.pisukat"         . "\n  katalog kucista se pise u %1")
   ("info.pisukbl"         . "\n  katalog kablova se pise u %1")
   ("pomoc.otvaram"        . "\n  Otvaram uputstvo: %1")
   ("pomoc.nema"           . "\n  Uputstvo nije nadjeno.  Instalira se u folder FiberQ.bundle, pored LICENSE.")
   ("pomoc.nesme"          . "\n  Sistem nije uspeo da ga otvori.  Otvori gornji fajl rucno.")
   ("zak.stanje.zakljucan" . "zakljucan")
   ("zak.stanje.zamrznut"  . "zamrznut")
   ("zak.stanje.ugasen"    . "ugasen")
   ("zak.razlog"           . " -- lejer je %1")
   ("zak.razlog.nepoznat"  . " -- razlog nepoznat")
   ("zak.upis"             . "\nPAZNJA: upis nije uspeo na lejeru %1%2.\n  Nacrtano jeste, ali to specifikacija, budzet i FQTRASA NECE videti.\n  Otkucaj U da ponistis ceo potez, otkljucaj lejer, pa ponovi komandu.")
   ("zak.brisanje"         . "\nPAZNJA: brisanje nije uspelo na lejeru %1%2.\n  Stari crtez je ostao neizmenjen.\n  Otkucaj U da ponistis ceo potez, otkljucaj lejer, pa ponovi komandu.")
   ;; --- fq-kucista.lsp (blok 4.6) ---
   ("kuc.ram.ne"           . "\nRam kutije nije nacrtan, pa zapis nije upisan.")
   ("kuc.spl.nestaje.kutija" . "\nPAZNJA: spliter 1:%1 ne staje u kutiju od %2 konektora, crtam %3 izlaza.")
   ("kuc.spl.nestaje.ormar"  . "\nPAZNJA: spliter 1:%1 ne staje u %2 portova uz %3 zauzetih, crtam %4 izlaza.")
   ("zok.nacrtan"          . "\n%1%2%3  %4x%5%6, %7")
   ("zok.spliter"          . ", spliter 1:%1 sa konektora %2 na konektore 1-%3")
   ("zok.iskorisceno"      . ", iskorisceno %1 od %2")
   ("pp.nacrtan"           . "\n%1%2%3%4 konektora, iskorisceno %5 od %6, %7")
   ("pp.moduli"            . ", %1 modula po %2")
   ("pp.jedan"             . ", %1")
   ("odospl.nacrtan"       . "\n%1 (%2)%3, spliter 1:%4 sa porta %5 na portove %6-%7, %8%9")
   ("kuc.nepoznat.crtac"   . "\nNepoznat crtac za %1.")
   ("kuc.nema.rama"        . "\nUpozorenje: ne nalazim ram %1 da ga upisem kao %2.")
   ("kuc.pitaj.nakonektore" . "\nKoliko vlakana ide na konektore <%1>, najvise %2, 0 nijedno: ")
   ("kuc.nema.kabla"       . "\nU crtezu jos nema kabla, postavljam samostalno.")
   ("kuc.pitaj.samostalno" . "\nPostavi samostalno, bez kabla [%1/%2] <%3>: ")
   ("kuc.poravnanje"       . "\nPoravnanje postavljeno na %1. Sledeci kabl krece iz %2")
   ("kuc.por.vlakno"       . "dolaznog vlakna.")
   ("kuc.por.konektor"     . "prvog konektora.")
   ("kuc.dijalog.ne"       . "\nNe mogu da otvorim dijalog kucista.")
   ("kuc.nepoznata.vrsta"  . "\nNepoznata vrsta kucista: %1")
   ("kuc.montaza"          . "\nMontaza za %1: %2")
   ("kuc.pitaj.kapacitet"  . "\nKapacitet <%1>: ")
   ("kuc.pitaj.model"      . "\nModel <%1>: ")
   ("kuc.model.bez"        . "bez")
   ("kuc.pitaj.montaza"    . "\nMontaza <%1>: ")
   ("kuc.pitaj.letva"      . "\nLetva i modul <%1>: ")
   ("kuc.pitaj.moduli"     . "\nBroj modula <1>: ")
   ("kuc.pitaj.adresa"     . "\nAdresa ili lokacija: ")
   ("kuc.pitaj.odnos"      . "\nOdnos splitera 1:K, unesi K <%1>: ")
   ("kuc.pitaj.spliter"    . "\nSpliter unutar %1 [%2/%3] <%4>: ")
   ("kuc.kutije"           . "kutije")
   ("kuc.ormara"           . "ormara")
   ("kuc.nije.ram"         . "\nTo nije ram kucista.")
   ("kuc.klikni.ram"       . "\nKlikni na pravougaonik ODF-a, patch panela, ormara ili kutije.")
   ("kuc.pitaj.dodaj"      . "\nKuciste na koje se dodaje vlakno: ")
   ("kuc.ugao.nema"        . "\n%1: ne mogu da procitam ugao rama.")
   ("kuc.ugao.razlika"     . "\n%1 je nacrtan pod %2 stepeni, a taj kabl ide pod %3.\nKlikni vlakno kabla koji je u istoj orijentaciji kao kuciste.")
   ("kuc.ima.spliter"      . "\n%1 ima spliter u sebi (%2): svi izlazi su vec nacrtani,\nnema sta da se doda i ram se ne precrtava.")
   ("kuc.spl.rastegnut"    . "\n%1 ima spliter u sebi (%2), pa se ne precrtava - ram je samo rastegnut preko snopa od %3 vlakana.\n  Portovi, telo i lepeza ostaju gde jesu; vlakna bez porta su rezerva.")
   ("spl.dopisano"         . "\n%1 ima spliter u sebi (%2): %3 vlakno(a) prikljuceno na portove %4 do %5, zauzeto %6 od %7.\n  Telo, lepeza i svaki zatecen port ostaju netaknuti - dopisani su samo novi portovi.")
   ("kuc.samo.ram"         . "\n%1: ram je rastegnut preko celog snopa, veze se ne diraju.")
   ("kuc.pitanje.otkazano" . "\n  Pitanje otkazano - veze ostaju kakve jesu, ram i dalje prati kabl.")
   ("kuc.naslov.ostaje"    . "\n%1: drugo kuciste stoji odmah iznad rama, pa natpisi iznad njega ostaju.\n  Sta god se udvoji - oznaka, model - obrisi gornji primerak rucno.")
   ("kuc.montaza.ostaje"   . "\n%1: drugo kuciste stoji odmah ispod rama, pa natpisi ispod njega ostaju.\n  Sta god se udvoji, obrisi donji primerak rucno.")
   ("kuc.nije.obrisan"     . "\n%1: stari crtez nije obrisan (%2 od %3 delova), pa nov NIJE nacrtan.\n  Otkljucaj lejere kucista pa ponovi FQDODAJ.")
   ("dod.pitaj.koliko"     . "\nKoliko jos vlakana povezati <%1>, najvise %2, 0 samo siri ram: ")
   ("dod.nema.sta"         . "\n%1: nema sta jos da se poveze, ram se samo siri.")
   ("dod.pun"              . "\n%1: svih %2 konektora je zauzeto; ostatak snopa ostaje u kaseti.\n  Za njih ide veci modul, ili jos jedan modul razdelnika (FQKUC).")
   ("dod.rezultat"         . "\n%1: %2")
   ("dod.povezano"         . "povezano jos %1, ukupno %2 od %3 konektora.")
   ("dod.rasireno"         . "ram obuhvata snop od %1 vlakana, na konektorima %2 od %3.")
   ("dod.sva.vezana"       . "\nSva vlakna tog kabla su vec vezana na %1.")
   ("dod.nijedno"          . "\nNijedno vlakno tog kabla ne prolazi kroz %1.\nProveri da li je kliknut isti kabl i isti kraj kao pri postavljanju.")
   ("dod.ne.zavrsavaju"    . "\nTa vlakna ne zavrsavaju kod %1.\nKlikni vlakno na onom kraju kabla gde kuciste stoji.")
   ("por.nije.ni"          . "\nTo nije ni vlakno ni ram kucista ili nastavka.")
   ("por.klikni"           . "\nKlikni vlakno, ili pravougaonik ODF-a, ormara, kutije ili nastavka.")
   ("osp.nije.ormar"       . "\n%1 nije ni ormar ni kutija.")
   ("osp.kutija.savet"     . "\nSpliter ide u ormar (ODO) ili u kutiju (ZOK). U letvu razdelnika se ne crta, a nastavak nema kolonu konektora na koju bi izlazi legli.")
   ("osp.kutija.vise"      . "\n%1 vec ima %2 vlakna na konektorima, a kutija sa spliterom se gradi oko jednog dolaznog vlakna.\nNacrtaj kutiju sa spliterom od pocetka, ili u nju dovedi samo napojno vlakno.")
   ("osp.prazan"           . "\n%1 nema kabl u sebi, pa se spliter napaja sa prvog konektora rama. Vlakno se ne klikce.")
   ("osp.vec.ima"          . "\n%1 vec ima spliter u sebi.")
   ("osp.nema.porta"       . "\n%1 nema nijedan zauzet port, pa spliter nema odakle da se napaja.")
   ("osp.prvo.kabl"        . "\nPrvo dovedi kabl, pa onda spliter.")
   ("osp.pun"              . "\n%1 je pun: svih %2 portova je zauzeto.")
   ("osp.ugao"             . "\n%1 je nacrtan pod uglom %2 stepeni, a taj kabl pod %3 stepeni.")
   ("osp.ne.zavrsavaju"    . "\nTa vlakna ne zavrsavaju kod %1.\nKlikni vlakno na onom kraju kabla gde ormar stoji.")
   ("osp.pitaj.port"       . "\nPort sa koga se spliter napaja <%1>: ")
   ("osp.dodat"            . "\n%1: spliter dodat sa porta %2, ukupno %3 od %4 portova.")
   ("izv.nije.ram"         . "\nTo nije ram kucista ni nastavka.")
   ("izv.klikni"           . "\nKlikni pravougaonik ODF-a, patch panela, ormara, kutije ili nastavka.")
   ("izv.pitaj.ram"        . "\nKuciste ili nastavak iz kog kabl izlazi: ")
   ("izv.snop.siri"        . "\nPAZNJA: snop od %1 vlakana je siri od rama, prve vertikale izlaze levo od njega.")
   ("izv.nema.temena"      . "\nTaj ram nema temena.")
   ("izv.ogledalo"         . "\n%1 je ogledalno, pa bi izvod usao u samo telo ormara. Umesto toga povuci kabl komandom FQLOM ili FQODVOD.")
   ("izv.iz.nastavka"      . "\nIzvod iz nastavka %1, nacrtan pod %2 stepeni.")
   ("izv.vec.ima"          . "\n  U ramu vec ima izvoda, nov ide levo od njega.")
   ("izv.ram.prosiren"     . "\n  Ram nastavka je prosiren.")
   ("izv.savet.spoji"      . "\n  Vlakna izvoda i dolazna vlakna se spajaju dugmetom Spoji ili Spoji grupu.")
   ("izv.kutija.spliter"   . "\n%1 ima spliter, pa kabl dalje ne izlazi.")
   ("izv.klikni.kuc"       . "\nKlikni pravougaonik ormara, kutije ili modula.")
   ("izv.iz.kucista"       . "\nIzvod iz %1, kuciste je nacrtano pod %2 stepeni.")
   ("izv.pitaj.lakat"      . "\nVlakna izvoda unutar kucista [%1/%2] <%3>: ")
   ("izv.tok.lakat"        . "Lakat")
   ("izv.tok.prava"        . "Prava")
   ("izv.bez.lakta"        . "\n  Vlakna ne dolaze do kolone konektora, pa ram ostaje kakav je i nista se ne prikljucuje.")
   ("izv.nacrtan"          . "\nIzvod %1  %2 iz %3, %4 vlakana, duzina %5.")
   ("izv.donji.kraj"       . "\n  Na donjem kraju je obican kraj kabla: tu idu nastavak, spliter ili sledece kuciste.")
   ("ops.sada.pise"        . "\nSada pise: %1")
   ("ops.pitaj.opis"       . "\nOpis vlakna, prazno brise: ")
   ("ops.nije.obrisan"     . "\nStari opis nije obrisan, pa nista nije promenjeno.\n  Otkljucaj lejer na kome stoji tekst pa ponovi FQOPIS.")
   ("ops.obrisan"          . "\nOpis obrisan.")
   ("ops.upisano"          . "\nUpisano: %1")
   ("kat.sacuvan"          . "\nKatalog kucista sacuvan u %1")
   ("kat.ne.sacuvan"       . "\nNe mogu da sacuvam katalog kucista u %1")
   ("izv.prikljucivanje.ne" . "\n  Prikljucivanje nije uspelo: ")
   ;; --- editor color code standarda i promptovi kroz omotace (blok 4.7) ---
   ("cc.info.stanje"       . "Aktivan: %1     izabran: %2  (%3 boja)     nista nije trajno dok se ne sacuva")
   ("cc.info.izaberi.boju" . "Izaberi boju iz spiska poznatih boja.")
   ("cc.info.dodata"       . "Dodata boja %1 kao %2. po redu.")
   ("cc.info.prazan"       . "Standard nema nijednu boju.")
   ("cc.info.uklonjena"    . "Boja uklonjena iz standarda.")
   ("cc.info.kraj"         . "Nema kuda dalje.")
   ("cc.info.pomerena"     . "Boja je sada %1. po redu.")
   ("cc.info.izaberi.mesto" . "Izaberi mesto u standardu i boju iz spiska.")
   ("cc.info.zamenjena"    . "%1. mesto je sada %2.")
   ("cc.info.niz"          . "Upisi boje odvojene zarezom, pa klikni Primeni niz.")
   ("cc.info.ne.prepoznato" . "Nijedna boja nije prepoznata.")
   ("cc.info.upisano"      . "Upisano boja: %1%2")
   ("cc.info.nepoznate"    . "     nije prepoznato: %1")
   ("cc.info.grupe"        . "Oznake grupa upisane uz standard.")
   ("cc.info.upisi.naziv"  . "Upisi naziv u polje Naziv, pa klikni dugme.")
   ("cc.info.osnovni.pre"  . "Osnovni standard ne moze da se preimenuje, koristi Kopiraj.")
   ("cc.info.novi.naziv"   . "Upisi novi naziv u polje Naziv.")
   ("cc.info.preimenovano" . "Preimenovano u %1.")
   ("cc.info.osnovni.bri"  . "Osnovni standard ne moze da se obrise.")
   ("cc.info.bar.jedan"    . "Mora ostati bar jedan standard.")
   ("cc.info.potvrdi"      . "Klikni Obrisi jos jednom da potvrdis brisanje \"%1\".")
   ("cc.info.obrisan"      . "Standard obrisan.")
   ("cc.info.prazan.aktivan" . "Standard nema nijednu boju, ne moze biti aktivan.")
   ("cc.info.aktivan"      . "Aktivan standard je sada %1.")
   ("cc.info.sacuvano"     . "Sacuvano u %1")
   ("cc.info.ne.mogu"      . "Ne mogu da upisem: %1")
   ("kuc.nije.prosireno"   . "\n  Kuciste na kraju kabla nije prosireno: ")
   ("kabl.pitaj.duzina"    . "\nDuzina linije <%1>: ")
   ("opste.pitaj.tacka"    . "\nTacka: ")
   ("rez.pitaj.duzina"     . "\nDuzina rezerve u m <15>: ")
   ("por.pitaj.izbor"      . "\nIzaberi vlakno, ili ram kucista ili nastavka, sa kojim treba poravnati novi kabl: ")
   ("nast.pitaj.vlakno"    . "\nVlakno kabla, klikni blizu kraja koji ulazi u nastavak: ")
   ("spoj.pitaj.prvo"      . "\nIzaberi prvo vlakno, blizu kraja koji spajas: ")
   ("spoj.pitaj.drugo"     . "\nIzaberi drugo vlakno, blizu kraja koji spajas: ")
   ("spoj.pitaj.mesto"     . "\nPokazi mesto spoja duz kabla: ")
   ("spl2.pitaj.mesto"     . "\n  Pokazi mesto splajsa duz kabla: ")
   ("spl2.tok.tacka"       . "Tacka")
   ("spl2.tok.sredina"     . "Sredina")
   ("spl2.tok.prozor"      . "Prozor")
   ("spl2.pitaj.vlakno"    . "\nVlakno na koje ide splajs [%1/%2/%3] (Enter za kraj): ")
   ("grp.pitaj.a"          . "\nPOCETNO vlakno kabla A, klikni blizu kraja koji se spaja: ")
   ("grp.pitaj.b"          . "\nPOCETNO vlakno kabla B, klikni blizu kraja koji se spaja: ")
   ("odv.pitaj.prvo"       . "\nPRVO vlakno odvoda, klikni blizu kraja koji se odvodi: ")
   ("odv.pitaj.gde"        . "\nPokazi gde odvod stize, red PRVOG vlakna: ")
   ("prs.pitaj.gde"        . "\nPokazi gde se vlakno preseca: ")
   ("prs.pitaj.ugao1"      . "\nPrvi ugao prozora, unutar nastavka ili kucista: ")
   ("prs.tok.prozor"       . "Prozor")
   ("prs.pitaj.vlakno"     . "\nVlakno za presecanje, klikni ga u nastavku ili kucistu [%1] (Enter za kraj): ")
   ("pro.pitaj.vlakno"     . "\nVlakno koje treba da bude prolazno (Enter za kraj): ")
   ("pro.pitaj.krak"       . "\n  Nema splajsa na tom vlaknu. Klikni DRUGI krak, bilo gde po njemu, da se spoje u pravo vlakno (Enter samo upisuje prolazno): ")
   ("tras.pitaj.vlakno"    . "\nIzaberi vlakno cija te trasa zanima: ")
   ("info.pitaj.element"   . "\nIzaberi element seme: ")
   ("leg.pitaj.tacka"      . "\nTacka umetanja legende (gore levo): ")
   ("kuc.pitaj.vlakno"     . "\nVlakno kabla, klikni blizu kraja gde stoji %1: ")
   ("kuc.pitaj.dolazno"    . "\nTacka dolaznog vlakna, %1: ")
   ("osp.pitaj.vlakno"     . "\nVlakno kabla koji ulazi u %1, klikni blizu kraja kod ormara: ")
   ("ops.pitaj.vlakno"     . "\nVlakno kome se upisuje opis: ")
   ("cc.info.vec.postoji"  . "Standard sa tim nazivom vec postoji.")
   ("cc.info.kopija"       . "Napravljena kopija %1.")
   ("cc.info.prazan.nov"   . "Napravljen prazan standard %1.")
   ("kuc.pitaj.prvo"       . "\nTacka prvog vlakna, %1: ")

   ;; --- DCL, blok 5 -----------------------------------------------

   ;; zajednicko vise dijaloga
   ("dcl.ok"               . "OK")
   ("dcl.odustani"         . "Odustani")
   ("dcl.zatvori"          . "Zatvori")
   ("dcl.status"           . "Status")
   ("dcl.status.proj"      . "Projektovano")
   ("dcl.status.izv"       . "Izvedeno")
   ("dcl.ispis"            . "Ispisuje se u crtezu")
   ("dcl.kapacitet"        . "Kapacitet")
   ;; 1 cevka, 2-4 cevke, 5 i vise cevki -- poslednja cifra odlucuje,
   ;; sem za 11-14.  Racun je u fq:kapzagl, ovde su samo oblici.
   ("dcl.kap.cev1"         . "-- %1 cevka --")
   ("dcl.kap.cev24"        . "-- %1 cevke --")
   ("dcl.kap.cev5"         . "-- %1 cevki --")
   ("dcl.oznaka"           . "Oznaka")
   ("dcl.orijentacija"     . "Orijentacija")
   ("dcl.ori.h"            . "Horizontalno")
   ("dcl.ori.v"            . "Vertikalno")
   ("dcl.ori.gore"         . "Vertikalno nagore")
   ("dcl.ori.dole"         . "Vertikalno nadole")

   ;; naslovi prozora
   ("dcl.naslov.kabl"      . "FiberQ CAD  -  novi kabl")
   ("dcl.naslov.nast"      . "FiberQ CAD  -  nastavak")
   ("dcl.naslov.kuc"       . "FiberQ CAD  -  kuciste")
   ("dcl.naslov.cc"        . "FiberQ CAD  -  color code standardi")
   ("dcl.naslov.pal"       . "FiberQ CAD  -  elementi seme")

   ;; nastavak
   ("dcl.nast.tip"         . "Tip")
   ("dcl.nast.tn"          . "N  obican")
   ("dcl.nast.tl"          . "NL  latentni")
   ("dcl.nast.ozn"         . "Oznaka   (dovoljan je broj)")
   ("dcl.nast.gde"         . "Gde se nalazi")
   ("dcl.nast.broj"        . "Broj")
   ("dcl.nast.serija"      . "Serija")
   ("dcl.nast.vise"        . "Nastavi, odmah pitaj za sledeci nastavak")
   ("dcl.nast.isti"        . "Isti kabl, ne biraj vlakno ponovo")

   ;; kabl
   ("dcl.kabl.tip"         . "Tip kabla")
   ("dcl.kabl.cc"          . "Color code")
   ("dcl.kabl.vrsta"       . "Vrsta vlakna")
   ("dcl.kabl.ozn"         . "Oznaka, opciono")
   ("dcl.kabl.duz"         . "Duzina, polazna")
   ("dcl.kabl.dul"         . "Duzinu povuci misem posle tacke umetanja")
   ("dcl.kabl.lom"         . "Kabl sa lomovima, putanja se klikce")

   ;; kuciste
   ("dcl.kuc.vrsta"        . "Vrsta")
   ("dcl.kuc.model"        . "Model  (proizvodjac i tip)")
   ("dcl.kuc.konektor"     . "Tip konektora")
   ("dcl.kuc.montaza"      . "Montaza")
   ("dcl.kuc.iskorisceno"  . "Iskorisceno")
   ("dcl.kuc.letva"        . "Letva i modul")
   ("dcl.kuc.modula"       . "Modula")
   ("dcl.kuc.adresa"       . "Adresa ili lokacija")
   ("dcl.kuc.spliter"      . "Spliter unutar kutije")
   ("dcl.kuc.kacenje"      . "Kacenje")
   ("dcl.kuc.na.kabl"      . "Na kabl")
   ("dcl.kuc.samostalno"   . "Samostalno")
   ("dcl.kuc.nema.modela"  . "(nema upisanih)")

   ;; color code
   ("dcl.cc.standardi"     . "Standardi")
   ("dcl.cc.naziv"         . "Naziv")
   ("dcl.cc.novi"          . "Novi")
   ("dcl.cc.kopiraj"       . "Kopiraj")
   ("dcl.cc.preimenuj"     . "Preimenuj")
   ("dcl.cc.obrisi"        . "Obrisi")
   ("dcl.cc.aktivan"       . "Postavi kao aktivan")
   ("dcl.cc.redosled"      . "Redosled u standardu")
   ("dcl.cc.gore"          . "Gore")
   ("dcl.cc.dole"          . "Dole")
   ("dcl.cc.ukloni"        . "Ukloni")
   ("dcl.cc.zameni"        . "Zameni izabranom")
   ("dcl.cc.poznate"       . "Poznate boje")
   ("dcl.cc.dodaj"         . "Dodaj u standard")
   ("dcl.cc.ostala"        . "Ostala boja...")
   ("dcl.cc.niz"           . "Ceo niz odjednom, boje odvojene zarezom")
   ("dcl.cc.primeni.niz"   . "Primeni niz")
   ("dcl.cc.prefiksi"      . "Oznaka za vlakna preko duzine tabele, po grupama")
   ("dcl.cc.primeni.pre"   . "Primeni oznake")
   ("dcl.cc.sacuvaj"       . "Sacuvaj u fajl")
   ("dcl.cc.osnovni"       . "  osnovni")

   ;; paleta
   ("dcl.pal.status"       . "Status novih elemenata")
   ("dcl.pal.keep"         . "Zadrzi paletu otvorenu")
   ("dcl.pal.drag"         . "Pregled kabla uz mis")
   ("dcl.pal.siri"         . "Kabl siri kuciste na svom kraju")
   ("dcl.pal.snap"         . "Hvatanje na prvi konektor rama")

   ;; natpisi koje dijalog puni u toku rada, kroz set_tile
   ("dcl.kabl.kategorija"  . "Kategorija:  %1")
   ("dcl.nast.kbl.isti"    . "kabl %1, bira se samo ram")
   ("dcl.nast.kbl.novi"    . "kabl se bira klikom na vlakno")
   ("dcl.kuc.pre.moduli"   . "   %1 modula, ukupno %2")
   ("dcl.kuc.pre.spliter"  . "   spliter 1:%1")
   ("dcl.pal.info"         . "Status: %1     Color code: %2%3")
   ("dcl.pal.info.ormar"   . "     KABL KRECE IZ ORMARA")
   ("dcl.pal.info.kabl"    . "     PORAVNANJE UZ KABL")

   ;; --- paleta, stavke menija, blok 6 -----------------------------
   ("menu.grupa.kablovi"   . "Kablovi")
   ("menu.kabl.vazdusni"   . "Vazdusni...")
   ("menu.kabl.podzemni"   . "Podzemni...")
   ("menu.kabl.mikro"      . "Podzemni mikro...")
   ("menu.kabl.instalacioni" . "Instalacioni...")
   ("menu.kabl.rucni"      . "Rucni unos...")
   ("menu.kabl.poravnaj"   . "Poravnaj sa kablom")
   ("menu.kabl.cc"         . "Color code...")
   ("menu.kabl.vrsta"      . "Vrsta vlakna SM/MM...")
   ("menu.kabl.katalog"    . "Sacuvaj katalog kablova")

   ("menu.grupa.nastavci"  . "Nastavci i spajanje")
   ("menu.nast.n"          . "Nastavak N...")
   ("menu.nast.nl"         . "Nastavak NL latentni...")
   ("menu.nast.cmd"        . "Nastavak, komandna linija")
   ("menu.spoj.dva"        . "Spoji dva vlakna")
   ("menu.spoj.grupa"      . "Spoji grupu vlakana")
   ("menu.spoj.splajs"     . "Splajs na vlakno")
   ("menu.spoj.odvod"      . "Vertikalni odvod")
   ("menu.spoj.preseci"    . "Preseci vlakno")
   ("menu.spoj.prolaz"     . "Prolazno vlakno")
   ("menu.spoj.rezerva"    . "Rezerva 15 m")

   ("menu.grupa.spliteri"  . "Spliteri")
   ("menu.spl.2"           . "1:2")
   ("menu.spl.4"           . "1:4")
   ("menu.spl.8"           . "1:8")
   ("menu.spl.16"          . "1:16")
   ("menu.spl.32"          . "1:32")
   ("menu.spl.64"          . "1:64")
   ("menu.spl.ostalo"      . "Ostalo...")
   ("menu.spl.kuciste"     . "U ODO ili kutiju...")

   ("menu.grupa.odf"       . "ODF moduli")
   ("menu.odf.144"         . "ODF 144   (kabl 12x12)")
   ("menu.odf.96"          . "ODF 96    (kabl 8x12)")
   ("menu.odf.72"          . "ODF 72    (kabl 6x12)")
   ("menu.odf.48"          . "ODF 48    (kabl 4x12)")
   ("menu.odf.24"          . "ODF 24    (kabl 2x12)")
   ("menu.odf.12"          . "ODF 12    (kabl 1x12)")
   ("menu.odf.ostalo"      . "Ostalo...")

   ("menu.grupa.odo"       . "ODO ormari")
   ("menu.odo.24"          . "ODO 24")
   ("menu.odo.48"          . "ODO 48")
   ("menu.odo.96"          . "ODO 96")
   ("menu.odo.ostalo"      . "Ostalo...")

   ("menu.grupa.oltont"    . "OLT i ONT")
   ("menu.olt.8"           . "OLT 8 PON")
   ("menu.olt.16"          . "OLT 16 PON")
   ("menu.ont"             . "ONT korisnik")

   ("menu.grupa.namena"    . "Namena vlakna")
   ("menu.nam.radno"       . "Radno")
   ("menu.nam.planirano"   . "Planirano")
   ("menu.nam.izgradnja"   . "U izgradnji")
   ("menu.nam.primljeno"   . "Funkcionalno primljeno")
   ("menu.nam.rezervisano" . "Rezervisano")
   ("menu.nam.osteceno"    . "Osteceno")
   ("menu.nam.spliter"     . "Spliter")
   ("menu.nam.rezervno"    . "Rezervno")
   ("menu.nam.prolazno"    . "Prolazno")
   ("menu.nam.slobodno"    . "Slobodno (vrati crno)")

   ("menu.grupa.podaci"    . "Podaci i provere")
   ("menu.pod.info"        . "Podaci o elementu")
   ("menu.pod.trasa"       . "Trasa vlakna")
   ("menu.pod.bom"         . "Specifikacija u konzolu")
   ("menu.pod.tabela"      . "Specifikacija u crtez")
   ("menu.pod.budzet"      . "Opticki budzet")
   ("menu.pod.budzettab"   . "Budzet u crtez")
   ("menu.pod.provera"     . "Provera crteza")
   ("menu.pod.legenda"     . "Legenda simbola")
   ("menu.pod.stil"        . "Primeni standard lejera")
   ("menu.pod.verzija"     . "Verzija i okruzenje")
   ("menu.pod.pomoc"       . "Uputstvo")

   ;; --- prefiks i naziv vrste kucista, blok 7 ---------------------
   ("vrsta.pre.odo"        . "ODO ")
   ("vrsta.pre.zok"        . "ZOK ")
   ("vrsta.ime.odf"        . "ODF modul")
   ("vrsta.ime.pp"         . "Patch panel")
   ("vrsta.ime.odo"        . "ODO ormar")
   ("vrsta.ime.mdu"        . "MDU ormar")
   ("vrsta.ime.zok"        . "ZOK kutija")

   ;; --- nazivi boja, blok 8 ---------------------------------------
   ("boja.plava"          . "Plava")
   ("boja.narandzasta"    . "Narandzasta")
   ("boja.zelena"         . "Zelena")
   ("boja.braon"          . "Braon")
   ("boja.siva"           . "Siva")
   ("boja.bela"           . "Bela")
   ("boja.crvena"         . "Crvena")
   ("boja.crna"           . "Crna")
   ("boja.zuta"           . "Zuta")
   ("boja.ljubicasta"     . "Ljubicasta")
   ("boja.roze"           . "Roze")
   ("boja.tirkizna"       . "Tirkizna")

   ;; --- legenda: tekst koji ide U CRTEZ, blok 8 --------------------
   ("leg.naslov"          . "LEGENDA SIMBOLA")
   ("leg.vlakno"          . "Vlakno, linija crna, oznaka u boji po color code-u")
   ("leg.kabl"            . "Kabl, cevcica sa brojem uvucena od krajeva")
   ("leg.nastavak"        . "Nastavak (spojnica), oznaka iznad rama")
   ("leg.varenje"         . "Varenje dva vlakna")
   ("leg.spliter"         . "Spliter 1:K sa gubitkom u dB")
   ("leg.odo"             . "ODO ormar sa zauzetim portovima")
   ("leg.odf"             . "ODF modul, konektori numerisani 1..N")
   ("leg.olt"             . "OLT sa PON portovima")
   ("leg.ont"             . "ONT sa privodom do korisnika")
   ("leg.rezerva"         . "Rezerva kabla, R = duzina u m")
   ("leg.namena"          . "NAMENA VLAKNA")
   ("leg.colorcode"       . "COLOR CODE:  %1")
  ))

;;; ------------------------------------------------------------------
;;;  3. PREVOD
;;; ------------------------------------------------------------------

;; Tabela tekuceg jezika.
;;
;;  LOKALNA SE NE SME ZVATI t.  AutoLISP ne razlikuje velika i mala
;;  slova u imenima simbola, pa bi (defun ... / t) postavilo T na nil na
;;  ulazu.  Isto upozorenje stoji uz fq:nazkod i vazi za ceo projekat --
;;  ovde dvostruko, jer se funkcija zove fq:t.
(defun fq:strtab (jez)
  (if (= (fq:jezok jez) "SR") *FQ-STR-SR* *FQ-STR-EN*))

;; Kljuc -> niska za prikaz.
;;
;;  UGOVOR: uvek vraca STRING, nikad nil.  nil u strcat prekida crtanje
;;  usred poteza -- isto pravilo koje vec vazi za fq:kc-zmod, fq:f,
;;  fq:nazkod i fq:kodnaz.
;;
;;  Tri koraka, tim redom:
;;    1. tekuci jezik
;;    2. engleski, jer je merodavan -- nepotpun srpski prevod daje
;;       englesku recenicu, a ne golu sifru
;;    3. sam kljuc, da se propust vidi u komandnoj liniji umesto da
;;       ostavi prazninu koja lici na uredan ispis
(defun fq:t (k / r)
  (cond
    ((not k) "")
    ((setq r (assoc k (fq:strtab *fq-jezik*))) (cdr r))
    ((setq r (assoc k *FQ-STR-EN*)) (cdr r))
    (T k)))

;; Kljuc + umeci -> niska.  %1 do %9 se zamenjuju clanovima vals, redom.
;;
;;  ZASTO BROJ, A NE STRCAT.  Danas se recenica sklapa ovako:
;;    (strcat "\nKabl " oz "   " tip " = " (itoa n) " vlakana")
;;  Red delova je tu zakucan u sam kod, pa se u drugom jeziku ne moze
;;  promeniti bez pisanja druge grane.  Sa %1 red je u TABELI, gde mu je
;;  i mesto, pa prevodilac sme da ga promeni.
;;
;;  vl-string-subst menja PRVO pojavljivanje.  To je ovde tacno ono sto
;;  treba: svaki umetak se pojavljuje jednom.  Ako se ikad pojavi dvaput,
;;  zameni se samo prvi -- vidi se odmah, ne tiho.
;;
;;  nil clan postaje prazan string, iz istog razloga zbog kog fq:t nikad
;;  ne vraca nil.
(defun fq:tf (k vals / s i)
  (setq s (fq:t k) i 1)
  (foreach v vals
    (setq s (vl-string-subst (if v v "") (strcat "%" (itoa i)) s)
          i (1+ i)))
  s)

;; Naziv jezika na tekucem jeziku, za poruke.
(defun fq:jeznaziv (jez) (fq:t (strcat "jezik.naziv." (fq:jezok jez))))

;;; ------------------------------------------------------------------
;;;  4. IZBOR JEZIKA
;;; ------------------------------------------------------------------

;; Postavlja jezik i pamti ga u AutoCAD profilu.
;;
;;  Vraca T ako se jezik stvarno promenio, nil ako je bio isti.  To
;;  koristi c:FQJEZIK da ne bi savetovao ponovno ucitavanje trake kad
;;  nema sta da se ucita.
(defun fq:jezik (jez / nov)
  (setq nov (fq:jezok jez))
  (if (= nov *fq-jezik*)
    nil
    (progn
      (setq *fq-jezik* nov)
      (setenv *FQ-JEZ-KLJUC* nov)
      (fq:trakazam)
      T)))

;;  Zamena paketa trake pri promeni jezika.
;;
;;  Traka nije DCL: ona se ne sklapa pri svakom otvaranju nego stoji
;;  ucitana, pa je prevod ne dodiruje sam od sebe.  Dva jezika su dva
;;  ODVOJENA .cuix fajla -- vidi make-cuix.ps1 -- i menjaju se skidanjem
;;  jednog i ucitavanjem drugog.
;;
;;  Radi se samo ako je traka ZATECENA ucitana.  Ko je radi bez trake
;;  ne dobija je zato sto je promenio jezik.
;;
;;  Straza na oba imena: ovaj fajl se ucitava PRVI, pre fq-ribbon.lsp, i
;;  sme da radi i sasvim bez njega.  Bez straze bi FQJEZIK pukao na
;;  nedefinisanu funkciju, i to tek u trenutku kad korisnik menja jezik.
(defun fq:trakazam ()
  (if (and (car (atoms-family 1 (list "FQ:MG")))
           (car (atoms-family 1 (list "C:FQRIBBON")))
           (fq:mg))
    (progn
      (vl-catch-all-apply 'c:FQRIBBONOFF nil)
      (vl-catch-all-apply 'c:FQRIBBON nil))))

;;  TOKENI OVE JEDNE KOMANDE SE NE PREVODE, i to je namerno.
;;
;;  Komanda za izbor jezika je jedina koju korisnik pokrece bas zato sto
;;  mu tekuci jezik ne odgovara.  Da su joj tokeni na tekucem jeziku,
;;  onaj ko je zatekao engleski a trazi srpski morao bi da procita
;;  engleski prompt da bi izasao iz engleskog.  Zato prompt nosi oba
;;  jezika, a tokeni su "English" i "Srpski" -- razumljivi u oba.
;;
;;  Za sve ostale komande vazi obrnuto pravilo, iz CLAUDE.md: token je
;;  interfejs i sme da se prevede, ali ono sto se iz njega izvede i
;;  upise mora kroz izricit cond.  Ovde se ne upisuje nista u crtez.
(defun c:FQJEZIK ( / *error* kw jez)
  (setq *error* fq:err)
  (initget "English Srpski")
  (setq kw (getkword (strcat "\nJezik / Language [English/Srpski] <"
                             *fq-jezik* ">: ")))
  (if (not kw)
    (princ (fq:tf "jezik.isti" (list (fq:jeznaziv *fq-jezik*))))
    (progn
      (setq jez (cond ((= kw "Srpski") "SR") (T "EN")))
      (if (fq:jezik jez)
        (princ (fq:tf "jezik.postavljen" (list (fq:jeznaziv jez))))
        (princ (fq:tf "jezik.isti" (list (fq:jeznaziv jez)))))))
  (princ))

;;; ------------------------------------------------------------------
;;;  ENGLESKA IMENA KOMANDI
;;;
;;;  Ime komande NE prati jezik i ne sme da ga prati.  Ono je simbol
;;;  odredjen pri ucitavanju, a AutoCAD tabelu prevoda imena (LINE /
;;;  LINIJA, odatle i podvlaka u makroima trake) drzi samo za svoje
;;;  ugradjene komande -- dodatak joj ne pristupa.
;;;
;;;  Da ime ipak prati jezik, dve stvari bi pukle istog trenutka:
;;;
;;;   1. CUIX makro zove ^C^C_FQZOK po imenu.  Prebacivanje jezika bi
;;;      dugme ostavilo da pokazuje na komandu koje vise nema.
;;;   2. Svaka zatecena korisnicka skripta i svaki makro prestaju da
;;;      rade.  To je isti razlog zbog kog su tokeni initget-a zamrznuti,
;;;      samo tezi: token pokvari jedno pitanje, ime pokvari ceo poziv.
;;;
;;;  Zato ALIAS, ne preimenovanje: drugo ime za istu komandu, koje radi
;;;  UVEK i na oba jezika.  Nista se ne uklanja, pa se nista ne lomi.
;;;
;;;  Obrazac je vec bio u kucu -- FQMDU* / FQIPAN* u fq-kucista.lsp,
;;;  gde FQIPAN* ostaje zauvek jer stoji u tudjim skriptama i u navici.
;;;  Ovde je samo primenjen na ostatak.
;;;
;;;  ZASTO OVDE, a ne uz svaku komandu: alias uz cilj bi ih razbacao na
;;;  cetiri fajla i sedamdesetak mesta, a ovo je spisak koji se cita kao
;;;  spisak.  Fajl se ucitava PRVI, pre nego sto ijedan cilj postoji, i
;;;  to je u redu: telo defun-a se ne razresava pri definiciji nego pri
;;;  pozivu.  Isti razlog zbog kog fq:err sme da stoji u c:FQJEZIK iznad.
;;;
;;;  Sto NIJE dobilo alias:
;;;   - imena koja su vec neutralna: FQ, FIBERQ, FQCC, FQBOM, FQINFO,
;;;     FQODF*, FQPP*, FQOLT*, FQONT*, FQMDU*, FQDRAG, FQSNAP, FQKUC
;;;   - FQORIH / FQORIV: ORI je orientation na oba jezika
;;;   - FQMNTU / FQMNTS / FQMNTM: one ne primaju kod nego NAZIV IZ
;;;     KATALOGA, koji je namerno jezicki neutralan i ne zna za kodove
;;;     (vidi CLAUDE.md, "Katalog ostaje na nazivima").  Alias bi ovde
;;;     zavarao -- promenilo bi se ime, a ono sto komanda prosledjuje
;;;     ostalo bi srpsko, jer tako mora
;;;   - FQVAR: on je vec alias, za FQSPOJ
;;;
;;;  ODO i ZOK dobijaju FDH i FAT, po tabeli naziva iz FAZA5-PLAN.md.
;;;  Blok 7 sme da OKRENE koji je od para nosilac tela, po uzoru na
;;;  FQMDU* / FQIPAN*; za rad je svejedno, oba imena rade i ovako.
;;; ------------------------------------------------------------------

;; --- kabl ---------------------------------------------------------
(defun c:FQCABLE     ( / *error*) (setq *error* fq:err) (c:FQKABL))
(defun c:FQCABLECAT  ( / *error*) (setq *error* fq:err) (c:FQKABLK))
(defun c:FQCABLESAVE ( / *error*) (setq *error* fq:err) (c:FQKABLSAVE))
(defun c:FQCAERIAL   ( / *error*) (setq *error* fq:err) (c:FQKVAZ))
(defun c:FQCDUCT     ( / *error*) (setq *error* fq:err) (c:FQKPOD))
(defun c:FQCMICRO    ( / *error*) (setq *error* fq:err) (c:FQKMIK))
(defun c:FQCINDOOR   ( / *error*) (setq *error* fq:err) (c:FQKINS))
(defun c:FQBEND      ( / *error*) (setq *error* fq:err) (c:FQLOM))
(defun c:FQALIGN     ( / *error*) (setq *error* fq:err) (c:FQPORAVNAJ))
(defun c:FQFIBERTYPE ( / *error*) (setq *error* fq:err) (c:FQVRSTA))
(defun c:FQLENGTH    ( / *error*) (setq *error* fq:err) (c:FQDUZINA))

;; --- nastavci i spajanje ------------------------------------------
(defun c:FQCLOSURE   ( / *error*) (setq *error* fq:err) (c:FQNASTAVAK))
(defun c:-FQCLOSURE  ( / *error*) (setq *error* fq:err) (c:-FQNASTAVAK))
(defun c:FQCLOSN     ( / *error*) (setq *error* fq:err) (c:FQNAS))
(defun c:FQCLOSNL    ( / *error*) (setq *error* fq:err) (c:FQNAL))
(defun c:FQJOIN      ( / *error*) (setq *error* fq:err) (c:FQSPOJ))
(defun c:FQJOING     ( / *error*) (setq *error* fq:err) (c:FQSPOJG))
(defun c:FQSPLICE    ( / *error*) (setq *error* fq:err) (c:FQSPLAJS))
(defun c:FQCUT       ( / *error*) (setq *error* fq:err) (c:FQPRESECI))
(defun c:FQTHROUGH   ( / *error*) (setq *error* fq:err) (c:FQPROLAZ))
(defun c:FQDROP      ( / *error*) (setq *error* fq:err) (c:FQODVOD))
(defun c:FQSLACK     ( / *error*) (setq *error* fq:err) (c:FQREZERVA))
(defun c:FQSLACK15   ( / *error*) (setq *error* fq:err) (c:FQREZ15))

;; --- spliteri -----------------------------------------------------
;; FQSPLITTER sa dva T: srpski je "spliter", engleski "splitter", i to
;; jedno slovo je tacno ono na kom engleski korisnik promasi.
(defun c:FQSPLITTER  ( / *error*) (setq *error* fq:err) (c:FQSPLITER))
(defun c:FQSPLIN     ( / *error*) (setq *error* fq:err) (c:FQSPLKUC))

;; --- ODO ormar -> FDH ---------------------------------------------
(defun c:FQFDH       ( / *error*) (setq *error* fq:err) (c:FQODO))
(defun c:-FQFDH      ( / *error*) (setq *error* fq:err) (c:-FQODO))
(defun c:FQFDH12     ( / *error*) (setq *error* fq:err) (c:FQODO12))
(defun c:FQFDH24     ( / *error*) (setq *error* fq:err) (c:FQODO24))
(defun c:FQFDH48     ( / *error*) (setq *error* fq:err) (c:FQODO48))
(defun c:FQFDH72     ( / *error*) (setq *error* fq:err) (c:FQODO72))
(defun c:FQFDH96     ( / *error*) (setq *error* fq:err) (c:FQODO96))
(defun c:FQFDHDLG    ( / *error*) (setq *error* fq:err) (c:FQODODLG))

;; --- ZOK kutija -> FAT --------------------------------------------
(defun c:FQFAT       ( / *error*) (setq *error* fq:err) (c:FQZOK))
(defun c:-FQFAT      ( / *error*) (setq *error* fq:err) (c:-FQZOK))
(defun c:FQFAT1      ( / *error*) (setq *error* fq:err) (c:FQZOK1))
(defun c:FQFAT2      ( / *error*) (setq *error* fq:err) (c:FQZOK2))
(defun c:FQFAT4      ( / *error*) (setq *error* fq:err) (c:FQZOK4))
(defun c:FQFAT6      ( / *error*) (setq *error* fq:err) (c:FQZOK6))
(defun c:FQFAT8      ( / *error*) (setq *error* fq:err) (c:FQZOK8))
(defun c:FQFAT12     ( / *error*) (setq *error* fq:err) (c:FQZOK12))
(defun c:FQFAT16     ( / *error*) (setq *error* fq:err) (c:FQZOK16))
(defun c:FQFAT24     ( / *error*) (setq *error* fq:err) (c:FQZOK24))

;; --- kucista, ostalo ----------------------------------------------
(defun c:FQBRANCH    ( / *error*) (setq *error* fq:err) (c:FQIZVOD))
(defun c:FQADD       ( / *error*) (setq *error* fq:err) (c:FQDODAJ))
(defun c:FQDESC      ( / *error*) (setq *error* fq:err) (c:FQOPIS))
(defun c:FQWIDEN     ( / *error*) (setq *error* fq:err) (c:FQSIRI))
(defun c:FQCATSAVE   ( / *error*) (setq *error* fq:err) (c:FQKATSAVE))

;; --- status novih elemenata ---------------------------------------
(defun c:FQSTDES     ( / *error*) (setq *error* fq:err) (c:FQSTPROJ))
(defun c:FQSTASB     ( / *error*) (setq *error* fq:err) (c:FQSTIZV))

;; --- namena vlakna ------------------------------------------------
;; FQPUR*, ne FQP*: FQPP* je vec patch panel, pa bi FQPPLAN stajalo
;; jedno slovo od FQPP144 i u spisku i u pamcenju.
(defun c:FQPURWORK   ( / *error*) (setq *error* fq:err) (c:FQNMRAD))
(defun c:FQPURPLAN   ( / *error*) (setq *error* fq:err) (c:FQNMPLA))
(defun c:FQPURBUILD  ( / *error*) (setq *error* fq:err) (c:FQNMIZG))
(defun c:FQPURACC    ( / *error*) (setq *error* fq:err) (c:FQNMPRI))
(defun c:FQPURRSVD   ( / *error*) (setq *error* fq:err) (c:FQNMRZS))
(defun c:FQPURDMG    ( / *error*) (setq *error* fq:err) (c:FQNMOST))
(defun c:FQPURSPL    ( / *error*) (setq *error* fq:err) (c:FQNMSPL))
(defun c:FQPURSPARE  ( / *error*) (setq *error* fq:err) (c:FQNMRZV))
(defun c:FQPURTHRU   ( / *error*) (setq *error* fq:err) (c:FQNMPRO))
(defun c:FQPURFREE   ( / *error*) (setq *error* fq:err) (c:FQNMSLO))
;; FQBOJA je izuzetak koji vredi objasniti: komanda se zove "boja", ali
;; pita NAMENU i boju samo izvede iz nje.  Englesko ime prati sta radi.
(defun c:FQPURPOSE   ( / *error*) (setq *error* fq:err) (c:FQBOJA))

;; --- podaci i provere ---------------------------------------------
(defun c:FQROUTE     ( / *error*) (setq *error* fq:err) (c:FQTRASA))
(defun c:FQBUDGET    ( / *error*) (setq *error* fq:err) (c:FQBUDZET))
(defun c:FQBUDGETTAB ( / *error*) (setq *error* fq:err) (c:FQBUDZETT))
(defun c:FQCHECK     ( / *error*) (setq *error* fq:err) (c:FQPROVERA))
(defun c:FQLEGEND    ( / *error*) (setq *error* fq:err) (c:FQLEGENDA))
(defun c:FQTABLE     ( / *error*) (setq *error* fq:err) (c:FQTABELA))
(defun c:FQVERSION   ( / *error*) (setq *error* fq:err) (c:FQVERZIJA))
(defun c:FQHELP      ( / *error*) (setq *error* fq:err) (c:FQPOMOC))
(defun c:FQSETTINGS  ( / *error*) (setq *error* fq:err) (c:FQSTANJE))
(defun c:FQLAYERS    ( / *error*) (setq *error* fq:err) (c:FQSTIL))
(defun c:FQLANG      ( / *error*) (setq *error* fq:err) (c:FQJEZIK))


;;; ------------------------------------------------------------------
;;;  BANER
;;;
;;;  Jedini fajl kome straza ne treba: fq:t je definisan dvadesetak
;;;  redova iznad.
;;; ------------------------------------------------------------------

(princ (strcat "\nFiberQ CAD " *FQ-VERZIJA*
               " -- fq-jezik.lsp ucitan / loaded.  FQJEZIK ["
               *fq-jezik* "]"))
(princ)
